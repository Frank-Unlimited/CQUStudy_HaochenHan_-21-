package com.example.puzzlegame2;

import ohos.agp.components.*;
import ohos.app.Context;

import java.util.List;

public class ImageListProvider extends BaseItemProvider {
    List<Integer> imgList;
    Context context;
    ClickedListener clickedListener;

    public void setListener(ClickedListener clickedListener){this.clickedListener= clickedListener;}
    public static interface ClickedListener{
        void click(int pos);
    }
    public ImageListProvider(List<Integer> imgList,Context context){
        this.imgList = imgList;
        this.context = context;
    }

    @Override
    public int getCount() {//图片列表的长度
        return imgList.size();
    }

    @Override
    public Object getItem(int i) {
        return imgList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public Component getComponent(int i, Component component, ComponentContainer componentContainer) {
        DirectionalLayout directionalLayout = (DirectionalLayout) LayoutScatter.getInstance(context).
                parse(ResourceTable.Layout_img_list_item,null,false);
        Image image = (Image) directionalLayout.findComponentById(ResourceTable.Id_img_list_item);
        image.setImageAndDecodeBounds(imgList.get(i));
        image.setClickedListener(new Component.ClickedListener() {
           @Override
           public void onClick(Component component) {
               clickedListener.click(i);
           }
        });
        return directionalLayout;
    }
}
