package com.example.puzzlegame2.slice.slice;

import com.example.puzzlegame2.History;
import com.example.puzzlegame2.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.animation.Animator;
import ohos.agp.animation.AnimatorGroup;
import ohos.agp.animation.AnimatorProperty;
import ohos.agp.animation.AnimatorValue;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.*;
import ohos.agp.components.element.PixelMapElement;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.render.Canvas;
import ohos.agp.render.Paint;
import ohos.agp.render.Texture;
import ohos.agp.utils.Color;
import ohos.agp.utils.LayoutAlignment;

import ohos.agp.window.dialog.CommonDialog;
import ohos.agp.window.dialog.IDialog;
import ohos.agp.window.dialog.ToastDialog;
import ohos.app.AbilityContext;
import ohos.global.resource.NotExistException;
import ohos.global.resource.Resource;
import ohos.media.image.PixelMap;
import ohos.media.image.common.ImageInfo;
import ohos.media.image.common.Rect;
import ohos.media.image.common.Size;


import java.io.IOException;

import java.util.*;



public class DynamicPageSlice extends AbilitySlice implements Component.ClickedListener{
    boolean donghua;
    int row_r , col_c;
    int row , col, chexiao_step, curr_chexiao_step;
    int picz_r ;
    int picz_c;
    int step = 0;
    Image current;
    PixelMap mp[][];
    Image pic[][];
    Integer pos[][];
    Image emp;
    TickTimer mytime;
    long starttime = 0;
    long passtime = 0;
    long fg = 0;
    int nowi, nowj, empi , empj;
    Text sp;
    Text chexiaoSp;
    Text donghuasp;
    Picker picker;
    Deque<History> history_queue = new ArrayDeque<>();

    /**
     * 渐变色背景
     */
    public static ShapeElement getButtonShape(AbilityContext context, float radius, int resStartId, int resEndId) {
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setCornerRadius(radius);
        shapeElement.setShape(ShapeElement.RECTANGLE);
        //color关键值
        RgbColor[] rgbColors = new RgbColor[]{
                RgbColor.fromArgbInt(context.getColor(resStartId)),
                RgbColor.fromArgbInt(context.getColor(resEndId))};
        shapeElement.setRgbColors(rgbColors);
        //线性变化：对应type="linear"
        shapeElement.setShaderType(ShapeElement.LINEAR_GRADIENT_SHADER_TYPE);
        //变化方向，从左到右：对应angle="0"
        shapeElement.setGradientOrientation(ShapeElement.Orientation.LEFT_TO_RIGHT);
        return shapeElement;
    }

    /**
     * 通过id获取View
     */
    public static <T extends Component> T findById(AbilitySlice context, int id) {
        return (T) context.findComponentById(id);
    }

    public void pic_cut(PixelMap pixelMap){
        ImageInfo info = pixelMap.getImageInfo();
        PixelMap.InitializationOptions opt = new ohos.media.image.PixelMap.InitializationOptions();
        int w = Math.min(info.size.height, info.size.width);
        opt.size = new Size();
        opt.size.width = opt.size.height = w;
        opt.pixelFormat = info.pixelFormat;
        opt.editable = true;
        Rect rect = new Rect();
        rect.minX = 0;
        rect.minY = 0;
        rect.width = col_c;
        rect.height = row_r;
        PixelMap pixelMap1 = PixelMap.create(pixelMap, rect,opt);
        current.setPixelMap(pixelMap1);
        info = pixelMap1.getImageInfo();
        row_r = (int)info.size.height/row;
        col_c = (int)info.size.width/col;
        int sz = Math.max(row_r , col_c);
        int t = 0;
        int pm_px = AttrHelper.vp2px(getContext().getResourceManager().getDeviceCapability().width,this);
        for(int i = 0 ; i < row ; i++)
            for(int j = 0 ; j < col ; j++){
                Rect r1 = new Rect();
                r1.height = row_r;
                r1.width = col_c;
                r1.minX = j*col_c;
                r1.minY = i*row_r;
                PixelMap tmp = PixelMap.create(pixelMap1 , r1 , opt);
                Canvas canvas = new Canvas(new Texture(tmp));
                Paint paint = new Paint();
                paint.setTextSize(sz);
                paint.setColor(Color.GRAY);
                canvas.drawText(paint , ""+(++t),col_c,row_r*2);
                mp[i][j] = tmp;
            }
        randomshell();

    }
    public void randomshell(){
        Vector<Integer> lst = new Vector<Integer>();
        //创建数组将存在的数字存入到数组中
        for(int i = 0 ; i <= row*col - 2 ; i++){
            lst.add(i);
        }
        int nixudui=0;
        Collections.shuffle(lst);//随机打乱
        while (true){
            int []arr=new int[row*col-1];
            for(int i=0;i<row*col-1;i++){
                arr[i]=lst.get(i);
            }
            nixudui=reversePairs(arr);
            if(nixudui%2==0&&nixudui!=0){
                break;
            }
            Collections.shuffle(lst);
        }
        lst.add(row*col-1);

        //将打乱后的顺序传入pos中，将图片按此顺序排列
        for(int i=0;i<=row*col-1;i++){
            pic[i/col][i%col+(i==row*col-1?1:0)].setPixelMap(mp[lst.get(i)/col][lst.get(i)%col]);
            pos[i/col][i%col+(i==row*col-1?1:0)]=lst.get(i);
        }
        empi=row-1;empj=col-1;emp=pic[empi][empj];
        pic[empi][empj].setPixelMap(ResourceTable.Media_emt);
    }
    public DirectionalLayout build_dl(int type){
        DirectionalLayout dl = new DirectionalLayout(this);
        if(type == 0)
            dl.setOrientation(Component.VERTICAL);
        else
            dl.setOrientation(Component.HORIZONTAL);
        dl.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setAlignment(LayoutAlignment.CENTER);
        return dl;
    }
    public int reversePairs(int[] record) {
        int len = record.length;

        if (len < 2) {
            return 0;
        }

        int[] copy = new int[len];
        for (int i = 0; i < len; i++) {
            copy[i] = record[i];
        }

        int[] temp = new int[len];
        return reversePairs(copy, 0, len - 1, temp);
    }
    private int reversePairs(int[] record, int left, int right, int[] temp) {
        if (left == right) {
            return 0;
        }

        int mid = left + (right - left) / 2;
        int leftPairs = reversePairs(record, left, mid, temp);
        int rightPairs = reversePairs(record, mid + 1, right, temp);

        if (record[mid] <= record[mid + 1]) {
            return leftPairs + rightPairs;
        }

        int crossPairs = mergeAndCount(record, left, mid, right, temp);
        return leftPairs + rightPairs + crossPairs;
    }
    private int mergeAndCount(int[] record, int left, int mid, int right, int[] temp) {
        for (int i = left; i <= right; i++) {
            temp[i] = record[i];
        }

        int i = left;
        int j = mid + 1;

        int count = 0;
        for (int k = left; k <= right; k++) {

            if (i == mid + 1) {
                record[k] = temp[j];
                j++;
            } else if (j == right + 1) {
                record[k] = temp[i];
                i++;
            } else if (temp[i] <= temp[j]) {
                record[k] = temp[i];
                i++;
            } else {
                record[k] = temp[j];
                j++;
                count += (mid - i + 1);
            }
        }
        return count;
    }
    public void set_but_back(Component component , int r , int g ,int b){
        ShapeElement element = new ShapeElement();
        element.setShape(ShapeElement.RECTANGLE);
        element.setCornerRadius(30);
        element.setRgbColor(new RgbColor(r,g,b));
        element.setStroke(10 , new RgbColor(243 , 177 , 17));
        component.setBackground(element);
    }
    @Override

    public void onStart(Intent intent) {
        donghua=false;
        super.onStart(intent);
        //super.setUIContent(ResourceTable.Layout_DynamicPageLayout);
        DirectionalLayout  dl = new DirectionalLayout(this);
        setBack(dl, ResourceTable.Media_dog);
        dl.setOrientation(Component.VERTICAL);
        dl.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
        dl.setHeight(ComponentContainer.LayoutConfig.MATCH_PARENT);
        dl.setAlignment(LayoutAlignment.TOP);
        row = intent.getIntParam("row_n", 3);
        col = intent.getIntParam("col_m", 3);
        chexiao_step = intent.getIntParam("chexiao_step", 3);
        curr_chexiao_step = chexiao_step;
        current = new Image(this);

        current.setScaleMode(Image.ScaleMode.STRETCH);
        current.setCornerRadius(50f);
        current.setHeight(AttrHelper.vp2px(180,this));
        current.setWidth(AttrHelper.vp2px(180,this));
        //current.setPixelMap(intent.getIntParam("imgsrc",ResourceTable.Media_mydog));
        current.setPixelMap(((Image)findComponentById(ResourceTable.Id_bedminton)).getPixelMap());
        pic = new Image[row+1][col+1];;
        mp = new PixelMap[row+1][col+1];
        pos = new Integer[row+1][col+1];
        for(int i = 0 ; i <= row ; i++)
            for(int j = 0 ; j <= col ; j++)
                pos[i][j] = -1;
        picz_r = (int)200/(row);
        picz_c = (int)200/(col);
        DirectionalLayout d_l = build_dl(1);
        d_l.setMarginLeft(100);//左边距
        d_l.setMarginTop(100);//上边距
        d_l.addComponent(current);
        DirectionalLayout d_one = build_dl(0);
        d_one.setMarginLeft(40);
        DirectionalLayout d_two = build_dl(1);
        //dl.addComponent(d_l);
        int sz =70;
        Text txt  = new Text(this);
        txt.setText("耗时： ");
        txt.setTextSize(sz);
        mytime = new TickTimer(this);
        mytime.setCountDown(false);

        mytime.setTextSize(sz);
        d_two.addComponent(txt);
        d_two.addComponent(mytime);
        Button but1 = new Button(this);
        but1.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        but1.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        but1.setText("难度： "+ row+"X" + col);
        but1.setTextSize(sz);
        d_one.setAlignment(LayoutAlignment.LEFT);
        d_one.addComponent(d_two);
        d_one.addComponent(but1);


        sp = new Text(this);
        sp.setTextSize(sz);
        sp.setText("步数："+step);
        d_one.addComponent(sp);
        chexiaoSp= new Text(this);
        chexiaoSp.setText("剩余撤销步数："+String.valueOf(curr_chexiao_step));
        chexiaoSp.setTextSize(40);
        d_one.addComponent(chexiaoSp);

        donghuasp = new Text(this);
        donghuasp.setText("关");
        donghuasp.setTextSize(40);
        Button donghua_btn = new Button(this);
        donghua_btn.setText("动画开/关");
        donghua_btn.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        donghua_btn.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        donghua_btn.setTextSize(40);
        donghua_btn.setBackground(getButtonShape(this, 54, ResourceTable.Color_dark_gray, ResourceTable.Color_l_g));
        donghua_btn.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                if(donghua==false){
                    donghua = true;
                    donghuasp.setText("开");
//                    donghua_btn.setText("动画关");
//                    donghua_btn.setBackground(getButtonShape((AbilityContext) getContext(), 54, ResourceTable.Color_light_yellow, ResourceTable.Color_zongse));
                }else {
                    donghua=false;
                    donghuasp.setText("关");

//                    donghua_btn.setText("动画开");
//                    donghua_btn.setBackground(getButtonShape((AbilityContext) getContext(), 54, ResourceTable.Color_dark_gray, ResourceTable.Color_l_g));
                }
            }
        });

        d_one.setBackground(getButtonShape(this, 54, ResourceTable.Color_light_yellow, ResourceTable.Color_zongse));
        d_one.setPadding(20, 20,20,20);
        DirectionalLayout dd = build_dl(1);
        dd.addComponent(donghua_btn);
        dd.addComponent(donghuasp);
        d_one.addComponent(dd);
        d_l.addComponent(d_one);
        dl.addComponent(d_l);
        //图片的切分与显示
        for(int i = 0 ; i <= row ; i++)
            for(int j = 0 ; j <= col ; j++){
                pic[i][j] = new Image(this);
                pic[i][j].setWidth(AttrHelper.vp2px(picz_c,this));
                pic[i][j].setHeight(AttrHelper.vp2px(picz_r,this));
                pic[i][j].setScaleMode(Image.ScaleMode.STRETCH);
                if(j!=0)
                    pic[i][j].setMarginLeft(15);
                pic[i][j].setMarginTop(15);//上边距
                pic[i][j].setPixelMap(ResourceTable.Media_emt);
                if(i == row -1)
                    pic[i][j].setMarginBottom(30);
                pic[i][j].setClickedListener(this);

            }
        pic[row-1][col].setMarginRight(30);
        DirectionalLayout nd = build_dl(0);
        nd.setMarginTop(100);
        nd.setAlignment(LayoutAlignment.TOP);
        //这个地方有疑问//

        PixelMap px = current.getPixelMap();

        pic_cut(px);//裁剪图片并打乱
        //在nd中添加线性布局将各个图片放到相应的位置
        for(int i=0;i<row;i++){
            DirectionalLayout tmpd =new DirectionalLayout(this);
            tmpd.setMarginLeft(40);
            tmpd.setOrientation(Component.HORIZONTAL);
            tmpd.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
            tmpd.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
            for(int j=0;j<col;j++){
                tmpd.addComponent(pic[i][j]);
            }
            if(i==row-1){
                tmpd.addComponent(pic[i][col]);
            }
            nd.addComponent(tmpd);
        }
        nd.setBackground(getButtonShape(this, 54, ResourceTable.Color_light_yellow, ResourceTable.Color_zongse));
        dl.addComponent(nd);//在全局布局中添加nd组件

        DirectionalLayout d2=new DirectionalLayout(this);//新建线性布局来显示按钮
        d2.setMarginLeft(100);d2.setMarginTop(100);//设置各种参数
        d2.setOrientation(Component.HORIZONTAL);
        d2.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        d2.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        d2.setAlignment(LayoutAlignment.HORIZONTAL_CENTER);

        Button ret =new Button(this);
        ret.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        ret.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        ret.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
        ret.setText("结束游戏");
        ret.setTextSize(50);
        //设置点击事件
        ret.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                CommonDialog cd=new CommonDialog(getContext());//弹窗
                cd.setAlignment(LayoutAlignment.CENTER);
                cd.setTitleText("温馨提示");
                cd.setContentText("你还未完成，是否确认退出？");
                cd.setSize(900,400);
                cd.setCornerRadius(50);
                //点击事件
                cd.setButton(0, "是", new IDialog.ClickedListener() {
                    @Override
                    public void onClick(IDialog iDialog, int i) {
                        cd.destroy();;terminate();
                    }
                });
                cd.setButton(1, "否",new IDialog.ClickedListener() {
                    @Override
                    public void onClick(IDialog iDialog, int i) {
                        cd.destroy();
                    }
                });
                cd.show();
            }
        });
        ret.setPadding(20,20,20,20);
        d2.addComponent(ret);

        Button reset =new Button(this);//新建重置图片的按钮
        reset.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);//设置尺寸
        reset.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        reset.setText("重置游戏");//设置文本
        reset.setTextSize(50);//设置大小
        reset.setMarginLeft(100);//设置左间距
        //设置重置游戏的点击事件
        reset.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                starttime =System.currentTimeMillis();
                //timer.setBaseTime(startTime-passTime);
                mytime.setBaseTime(starttime);
                mytime.stop();fg=0;step=0;update();//重置游戏后所有参数置0
                history_queue.clear();
                curr_chexiao_step = chexiao_step;
                chexiaoSp.setText("剩余撤销步数："+String.valueOf(curr_chexiao_step));

                randomshell();//调用打乱函数
            }
        });
        reset.setPadding(20,20,20,20);//设置四方间距
        reset.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
        d2.addComponent(reset);//在d2中添加reset组件

        //撤销
        Button chexiao =new Button(this);//新建重置图片的按钮
        chexiao.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);//设置尺寸
        chexiao.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        chexiao.setText("撤销操作");//设置文本
        chexiao.setTextSize(50);//设置大小
        chexiao.setMarginLeft(100);//设置左间距
        //设置重置游戏的点击事件
        chexiao.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                if(curr_chexiao_step==0){
                    ToastDialog td = new ToastDialog(getContext());
                    td.setText("您的撤销步数用尽了");
                    td.show();
                }
                else if(history_queue.isEmpty()){
                    ToastDialog td = new ToastDialog(getContext());
                    if(step==0)
                        td.setText("您未进行任何操作");
                    else
                        td.setText("最多撤销3次");
                    td.show();
                }
                else{
                    --step;update();
                    --curr_chexiao_step;chexiaoSp.setText("剩余撤销步数："+String.valueOf(curr_chexiao_step));
                    History history = history_queue.pollLast();//取出最近一次操作
                    //还原现场
                    pos[nowi][nowj]  = pos[history.getNowi()][history.getNowj()];
                    pos[empi][empj] = pos[history.getEmpi()][history.getEmpj()];
                    empj = history.getEmpj();
                    empi = history.getEmpi();
                    emp = history.getEmp();

                    PixelMap p1 = history.getEmp().getPixelMap();
                    Component component1 = history.getClickedimg();
                    Image clickedIMG = (Image) component1;
                    PixelMap p2 = clickedIMG.getPixelMap();
                    if(donghua) {
                        move2(clickedIMG,emp);
                    }else {
                        move(clickedIMG,p2,p1);

                    }

                }
            }
        });
        chexiao.setPadding(20,20,20,20);//设置四方间距
        chexiao.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
        d2.addComponent(chexiao);//在d2中添加reset组件


        //在整体布局上添加d2
        dl.addComponent(d2);
        super.setUIContent(dl);
    }

    public void setBack(Component component, int id){
        try {
            Resource resource = getResourceManager().getResource(id);
            PixelMapElement pixelMapElement = new PixelMapElement(resource);
            component.setBackground(pixelMapElement);
        } catch (IOException e) {
            e.printStackTrace();
        }
        catch (NotExistException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }

    @Override
    public void onClick(Component component) {
        if(fg==0){
            starttime=System.currentTimeMillis();
            //timer.setBaseTime(startTime-passTime);
            mytime.setBaseTime(starttime);
            mytime.start();
            fg=1;
        }
        find(component);
        if(check()){
            ++step;update();
            Image clickedImage=(Image) component;

            History history = new History(nowi,nowj,empi,empj,emp,component);
            if(history_queue.size()>=3)
                history_queue.pollFirst();
            history_queue.addLast(history);

            //空白图片和点击的图片编号互换
            Integer tmp=pos[nowi][nowj];//点击的图片所在的编号
            pos[nowi][nowj]=pos[empi][empj];//点击的图片的编号 = 空白图片编号
            pos[empi][empj]=tmp;
            //判断是否完成拼图
            if(finished()){//完成游戏时计算时间，步数并弹窗提示
                double t=(System.currentTimeMillis()-starttime)/1000.0;
                String s=t+"";
                mytime.stop();
                CommonDialog cd=new CommonDialog(getContext());
                cd.setCornerRadius(25);
                cd.setSize(900,400);
                DirectionalLayout dl=build_dl(0);
                dl.setAlignment(LayoutAlignment.CENTER);
                Text title=new Text(this);title.setText("拼图完成!!!");title.setTextSize(85);
                title.setTextColor(Color.RED);
                Text content=new Text(this);content.setText("恭喜你，成功拼完整张图片！\n用时为："+s+"秒,一共"+step+"步");
                content.setTextSize(70);
                content.setMultipleLine(true);content.setMaxTextLines(4);
                Button but=new Button(this);but.setText("返回");but.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
                but.setWidth(200);
                but.setHeight(100);

                but.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
                but.setTextSize(65);

                but.setClickedListener(new Component.ClickedListener() {
                    @Override
                    public void onClick(Component component) {
                        cd.destroy();terminate();
                    }
                });
                dl.addComponent(title);dl.addComponent(content);dl.addComponent(but);
                cd.setContentCustomComponent(dl);
                cd.show();
            }
            //没有完成，移动空白图片和点击的图片
            PixelMap p1=clickedImage.getPixelMap();
            PixelMap p2=emp.getPixelMap();
            //move(clickedImage,p1,p2);
            //move2(clickedImage,emp);
            if(donghua) {
                move2(clickedImage,emp);
            }else {
                move(clickedImage,p1,p2);

            }

            //更新空白图片的内容和位置
            emp=clickedImage;
            empi=nowi;
            empj=nowj;

            //因此，撤销的历史记录需要维护：空白图片的内容和位置；空白图片和点击的图片编号(nowi,nowj,empi,empj,emp)


        }
    }
    public void find(Component component){
        for(int i=0;i<=row;i++){
            for(int j=0;j<=col;j++){
                if(component==pic[i][j]){
                    nowi=i;nowj=j;return;
                }
            }
        }
    }
    public void update(){
        sp.setText("步数："+step);
    }
    public boolean finished(){
        for(int i=0;i<row;i++){
            for(int j=0;j<col;j++){
                if(pos[i][j]!=(i)*col+j){return false;}
            }
        }
        return true;
    }
    public void move(Image c1, PixelMap p1, PixelMap p2) {
        c1.setPixelMap(p2);
        emp.setPixelMap(p1);
    }

    float s_x,s_y,f_x,f_y;
    public void move2(Image c1, Image c2){
        AnimatorProperty p1 = c1.createAnimatorProperty(), p2 = c2.createAnimatorProperty();
        AnimatorGroup ag = new AnimatorGroup();
        ag.setStateChangedListener(new Animator.StateChangedListener() {
            @Override
            public void onStart(Animator animator) {

            }

            @Override
            public void onStop(Animator animator) {

            }

            @Override
            public void onCancel(Animator animator) {

            }

            @Override
            public void onEnd(Animator animator) {
                c1.setContentPositionX(s_x);c1.setContentPositionY(s_y);
                c2.setContentPositionX(f_x);c2.setContentPositionY(f_y);
                PixelMap p1 = c1.getPixelMap();
                PixelMap p2 = c2.getPixelMap();
                c2.setPixelMap(p1);
                c1.setPixelMap(p2);

            }


            @Override
            public void onPause(Animator animator) {

            }

            @Override
            public void onResume(Animator animator) {

            }
        });
        ag.setDuration(100);
        s_x=c1.getContentPositionX();s_y=c1.getContentPositionY();
        f_x=c2.getContentPositionX();f_y=c2.getContentPositionY();
        int fg=0;
        if(s_x==f_x){
            if(nowi<empi) fg=1;
            else fg=-1;
            if(nowi<empi){
                p1.moveFromY(f_y).moveToY(f_y+15+picz_r);
                p2.moveFromY(f_y).moveToY(f_y-15-picz_r);
            }else {
                p2.moveFromY(f_y).moveToY(f_y+15+picz_r);
                p1.moveFromY(f_y).moveToY(f_y-15-picz_r);
            }
        }else {
            p1.moveFromX(s_x).moveToX(f_x);
            p2.moveFromX(f_x).moveToX(s_x);
        }
        ag.runParallel(p1,p1);
        ag.start();

    }

    public  boolean check(){
        if(Math.abs(nowi-empi)+Math.abs(nowj-empj)==1){
            return true;
        }
        return false;
    }

}