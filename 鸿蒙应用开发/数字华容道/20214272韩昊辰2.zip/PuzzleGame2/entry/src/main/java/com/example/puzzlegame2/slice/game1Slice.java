package com.example.puzzlegame2.slice;

import com.example.puzzlegame2.ImageListProvider;
import com.example.puzzlegame2.ResourceTable;
import com.example.puzzlegame2.slice.slice.DynamicPageSlice;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.ability.DataAbilityHelper;
import ohos.aafwk.ability.DataAbilityRemoteException;
import ohos.aafwk.content.Intent;
import ohos.aafwk.content.Operation;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.*;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.LayoutAlignment;
import ohos.agp.window.dialog.CommonDialog;
import ohos.agp.window.dialog.ToastDialog;
import ohos.app.AbilityContext;
import ohos.data.rdb.ValuesBucket;
import ohos.media.image.ImageSource;
import ohos.media.image.PixelMap;
import ohos.media.photokit.metadata.AVStorage;
import ohos.utils.PacMap;
import ohos.utils.net.Uri;

import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class game1Slice extends AbilitySlice {
    Image cur;
    Integer cur_src;
    Integer row_n,col_m,chexiao_step;
    private int RequestCode = 1314;//访问拍照权限所用的code
    Uri imageUri1;
    /**
     * 渐变色背景
     */
    public static ShapeElement getButtonShape(AbilityContext context, float radius, int resStartId, int resEndId) {
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setCornerRadius(radius);
        shapeElement.setShape(ShapeElement.RECTANGLE);
        //color关键值
        RgbColor[] rgbColors = new RgbColor[]{
                RgbColor.fromArgbInt(context.getColor(resStartId)),
                RgbColor.fromArgbInt(context.getColor(resEndId))};
        shapeElement.setRgbColors(rgbColors);
        //线性变化：对应type="linear"
        shapeElement.setShaderType(ShapeElement.LINEAR_GRADIENT_SHADER_TYPE);
        //变化方向，从左到右：对应angle="0"
        shapeElement.setGradientOrientation(ShapeElement.Orientation.LEFT_TO_RIGHT);
        return shapeElement;
    }

    public static ShapeElement setJianbian(AbilityContext context, int resStartId, int resEndId) {
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setShape(ShapeElement.RECTANGLE);
        //color关键值
        RgbColor[] rgbColors = new RgbColor[]{
                RgbColor.fromArgbInt(context.getColor(resStartId)),
                RgbColor.fromArgbInt(context.getColor(resEndId))};
        shapeElement.setRgbColors(rgbColors);
        //线性变化：对应type="linear"
        shapeElement.setShaderType(ShapeElement.LINEAR_GRADIENT_SHADER_TYPE);
        //变化方向，从左到右：对应angle="0"
        shapeElement.setGradientOrientation(ShapeElement.Orientation.LEFT_TO_RIGHT);
        return shapeElement;
    }

    /**
     * 通过id获取View
     */
    public static <T extends Component> T findById(AbilitySlice context, int id) {
        return (T) context.findComponentById(id);
    }

    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_game1);
        cur = (Image) findComponentById(ResourceTable.Id_bedminton);//当前页面上显示的大图
        ListContainer listContainer = (ListContainer) findComponentById(ResourceTable.Id_ListContainer);//图片列表容器
        List<Integer> imgList = getImagelist();//获取图片列表中的图片
        ImageListProvider imageListProvider = new ImageListProvider(imgList,this);//创建provider
        imageListProvider.setListener(new ImageListProvider.ClickedListener() {//provider点击事件
            @Override
            public void click(int pos) {
                cur.setPixelMap(imgList.get(pos));//imgList保存的图片id,将id映射为图片
                cur_src = imgList.get(pos);
            }
        });
        listContainer.setItemProvider(imageListProvider);//provider装入图片列表

        row_n=col_m=-1;

        //开始拼图
        Button begin = (Button) findComponentById(ResourceTable.Id_begin);
        Button btn_rectangle = (Button) findComponentById(ResourceTable.Id_begin);
        btn_rectangle.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));

        begin.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                if(row_n==-1||col_m==-1){
                    ToastDialog toastDialog = new ToastDialog(getContext());
                    toastDialog.setText("您还没有选择难度");
                    toastDialog.setAutoClosable(true);
                    toastDialog.show();
                }
                else{
                    Intent intent1 = new Intent();
                    AbilitySlice slice = new DynamicPageSlice();
                    //给下一个页面传参数
                    intent1.setParam("row_n",row_n);
                    intent1.setParam("col_m",col_m);
                    intent1.setParam("chexiao_step",chexiao_step);
                    intent1.setParam("imgsrc",cur_src);
                    present(slice,intent1);
                }
            }
        });

        //选择难度
        Button select = (Button) findComponentById(ResourceTable.Id_select);
        select.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
        select.setClickedListener(this::Select);

        //相册选择和拍照选择
        Button photo_album = (Button) findComponentById(ResourceTable.Id_photoAlbum);
        Button take_photo = (Button) findComponentById(ResourceTable.Id_takePhoto);
        photo_album.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
        take_photo.setBackground(getButtonShape(this, 54, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));

        //申请访问用户存储和相机权限
        requestPermissionsFromUser(new String[]{"ohos.permission.READ_USER_STORAGE","ohos.permision.CAMERA"},RequestCode);
        //响应事件
        photo_album.setClickedListener(component -> {
            select_pic();
        });
        take_photo.setClickedListener(component -> {
            take_photo();
        });

    }

    //选择照片
    private void select_pic(){
        Intent intent = new Intent();
        Operation operation =new Intent.OperationBuilder().withAction("android.intent.action.GET_CONTENT").build();
        intent.setOperation(operation);
        intent.addFlags(Intent.FLAG_NOT_OHOS_COMPONENT);
        intent.setType("image/*");
        startAbilityForResult(intent,RequestCode);
    }

    //拍照
    private void take_photo(){
        ValuesBucket valuesBucket = new ValuesBucket();
        valuesBucket.putString("relative_path","DCIM/Camera/");
        valuesBucket.putString(AVStorage.Images.Media.MIME_TYPE,"image/JPEG");
        DataAbilityHelper helper = DataAbilityHelper.creator(getContext());
        try {
            int id = helper.insert(AVStorage.Images.Media.EXTERNAL_DATA_ABILITY_URI,valuesBucket);
            imageUri1 = Uri.appendEncodedPathToUri(AVStorage.Images.Media.EXTERNAL_DATA_ABILITY_URI,String.valueOf(id));
            Intent intent = new Intent();
            Operation operation = new Intent.OperationBuilder()
                    .withAction("android.media.action.IMAGE_CAPTURE")
                    .build();
            intent.setOperation(operation);
            intent.setParam(AVStorage.Images.Media.OUTPUT,imageUri1);
            startAbilityForResult(intent,1);
            ToastDialog td = new ToastDialog(this);
            td.setText("试图拍照");
            td.show();
        } catch (DataAbilityRemoteException e){
            e.printStackTrace();
        }
    }


    //选择难度
    private void Select(Component component){
        CommonDialog cd = new CommonDialog(this);//创建常用对话框
        cd.setCornerRadius(40);
        cd.setAutoClosable(true);
        DirectionalLayout dl = new DirectionalLayout(this);
        DirectionalLayout dl1 = new DirectionalLayout(this);
        DirectionalLayout dl2 = new DirectionalLayout(this);
        DirectionalLayout dl3 = new DirectionalLayout(this);
        DirectionalLayout dl0 = new DirectionalLayout(this);


        //设置4个Layout属性
        dl.setOrientation(Component.VERTICAL);
        dl.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setAlignment(LayoutAlignment.CENTER);

        dl1.setOrientation(Component.HORIZONTAL);
        dl1.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl1.setHeight(ComponentContainer.LayoutConfig.MATCH_PARENT);
        dl1.setAlignment(LayoutAlignment.CENTER);

        dl2.setOrientation(Component.HORIZONTAL);
        dl2.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl2.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl2.setAlignment(LayoutAlignment.CENTER);

        dl3.setOrientation(Component.HORIZONTAL);
        dl3.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl3.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl3.setAlignment(LayoutAlignment.CENTER);

        dl0.setOrientation(Component.VERTICAL);
        dl0.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
        dl0.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl0.setAlignment(LayoutAlignment.CENTER);


        //设置dl背景
//        dl.setBackground(setJianbian(this, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
//        dl0.setBackground(setJianbian(this, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
//        dl2.setBackground(setJianbian(this, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
//        dl3.setBackground(setJianbian(this, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));



        //创建选择行数列数按钮，装入dl1
        Button tip = new Button(this);
        tip.setText("请选择难度"); tip.setTextSize(60);
        tip.setMarginLeft(100);
        dl0.addComponent(tip);
        Button row = new Button(this);
        Button col = new Button(this);
        Button chexiao = new Button(this);
        col.setTextSize(80);col.setText("行数");
        row.setTextSize(80);row.setText("列数");
        chexiao.setTextSize(50);chexiao.setText("最大撤销步数");
        row.setMarginLeft(100);col.setMarginLeft(200);chexiao.setMarginLeft(270);
        dl1.addComponent(row);dl1.addComponent(col);dl1.addComponent(chexiao);


        //创建两个picker装入dl2
        Picker picker = new Picker(this);
        Picker picker2 = new Picker(this);
        Picker picker3 = new Picker(this);
        picker.setMaxValue(10); picker2.setMaxValue(10);picker3.setMaxValue(10);
        picker.setMinValue(2);  picker2.setMinValue(2);picker3.setMinValue(3);
        picker.setNormalTextSize(50);   picker2.setNormalTextSize(50);picker3.setNormalTextSize(50);
        picker.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        picker2.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        picker3.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        picker.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        picker2.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        picker3.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        picker.setSelectedTextSize(100); picker2.setSelectedTextSize(100); picker3.setSelectedTextSize(100);
        picker.setMarginLeft(100);    picker2.setMarginLeft(200);picker3.setMarginLeft(300);
        dl2.addComponent(picker); dl2.addComponent(picker2);dl2.addComponent(picker3);

        //创建确认和返回按钮，确认按钮接受picker的值，加入dl3
        Button ack=new Button(this);//确认
        Button ret=new Button(this);//返回
        ack.setTextSize(80);
        ret.setTextSize(80);
        ack.setText("确认");
        ret.setText("返回");
        //返回按钮点击事件
        ret.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                row_n=col_m=-1;
                cd.destroy();
            }
        });
        //确认按钮点击事件
        ack.setClickedListener(new Component.ClickedListener() {
            @Override
            public void onClick(Component component) {
                row_n=picker.getValue();
                col_m=picker2.getValue();
                chexiao_step = picker3.getValue();
                cd.destroy();
            }
        });
        ret.setMarginLeft(200); ack.setMarginLeft(400);
        dl3.addComponent(ret);dl3.addComponent(ack);

        //dl1,2,3全部加入dl
        dl.addComponent(dl0);
        dl.addComponent(dl1);
        dl.addComponent(dl2);
        dl.addComponent(dl3);
        //dl加入cd
        cd.setContentCustomComponent(dl);
        cd.show();

//        //设置背景
//        DirectionalLayout dl_tmp = (DirectionalLayout) findComponentById(ResourceTable.Id_fourBut);
//        dl_tmp.setBackground(setJianbian(this, ResourceTable.Color_btn_start_search, ResourceTable.Color_btn_end_search));
    }

    public List<Integer> getImagelist(){
        List<Integer> integerList = new ArrayList<>();
        integerList.add(ResourceTable.Media_a1);
        integerList.add(ResourceTable.Media_a2);
        integerList.add(ResourceTable.Media_a3);
        integerList.add(ResourceTable.Media_a4);
        return integerList;
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }

    @Override
    protected void onAbilityResult(int requestCode, int resultCode, Intent resultData) {
        if(requestCode==RequestCode){//相册
            String ImgUri=null;
            try{
                ImgUri=resultData.getUriString();
            }catch (Exception e){
                return;
            }
            DataAbilityHelper helper = DataAbilityHelper.creator(getContext());
            ImageSource ims=null;
            String ImgId=null;
            if(ImgUri!=null&&ImgUri.lastIndexOf("%3A")!=-1){
                ImgId = ImgUri.substring(ImgUri.lastIndexOf("%3A")+3);
            }else {
                ImgId = ImgUri.substring(ImgUri.lastIndexOf('/')+1);
            }
            Uri uri = Uri.appendEncodedPathToUri(AVStorage.Images.Media.EXTERNAL_DATA_ABILITY_URI,ImgId);
            try{
                FileDescriptor fd=helper.openFile(uri,"r");
                ims=ImageSource.create(fd,null);
                PixelMap px=ims.createPixelmap(null);
                cur.setScaleMode(Image.ScaleMode.STRETCH);
                cur.setPixelMap(px);
            }catch (DataAbilityRemoteException e){
                e.printStackTrace();
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }finally {
                if(ims!=null){
                    ims.release();
                }
            }
        }
        else if(requestCode==1){//拍照
            ToastDialog td1 = new ToastDialog(this);
            td1.setText("进入拍照");
            td1.show();
            DataAbilityHelper helper = DataAbilityHelper.creator(getContext());
            Uri uri= imageUri1;
            try{
                FileDescriptor fd=helper.openFile(uri,"r");
                ImageSource ims = ImageSource.create(fd,null);
                PixelMap px = ims.createPixelmap(null);
                cur.setScaleMode(Image.ScaleMode.STRETCH);
                cur.setPixelMap(px);
            }catch (DataAbilityRemoteException e){
                e.printStackTrace();
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
            ToastDialog td = new ToastDialog(this);
            td.setText("开始拍照");
            td.show();
        }


    }
}
