package com.example.puzzlegame2.slice;

import com.example.puzzlegame2.ResourceTable;
import ohos.aafwk.ability.AbilitySlice;
import ohos.aafwk.content.Intent;
import ohos.agp.colors.RgbColor;
import ohos.agp.components.*;
import ohos.agp.components.element.ShapeElement;
import ohos.agp.utils.LayoutAlignment;
import ohos.agp.window.dialog.CommonDialog;
import ohos.app.AbilityContext;

public class MainAbilitySlice extends AbilitySlice {
    /**
     * 渐变色背景
     */
    public static ShapeElement getButtonShape(AbilityContext context, float radius, int resStartId, int resEndId) {
        ShapeElement shapeElement = new ShapeElement();
        shapeElement.setCornerRadius(radius);
        shapeElement.setShape(ShapeElement.RECTANGLE);
        //color关键值
        RgbColor[] rgbColors = new RgbColor[]{
                RgbColor.fromArgbInt(context.getColor(resStartId)),
                RgbColor.fromArgbInt(context.getColor(resEndId))};
        shapeElement.setRgbColors(rgbColors);
        //线性变化：对应type="linear"
        shapeElement.setShaderType(ShapeElement.LINEAR_GRADIENT_SHADER_TYPE);
        //变化方向，从左到右：对应angle="0"
        shapeElement.setGradientOrientation(ShapeElement.Orientation.LEFT_TO_RIGHT);
        return shapeElement;
    }

    /**
     * 通过id获取View
     */
    public static <T extends Component> T findById(AbilitySlice context, int id) {
        return (T) context.findComponentById(id);
    }
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setUIContent(ResourceTable.Layout_ability_main);
        //进入游戏
        Button btn_ingame = (Button) findComponentById(ResourceTable.Id_getingame);
        btn_ingame.setClickedListener(component -> {
            Intent intent1 = new Intent();
            AbilitySlice slice = new game1Slice();
            present(slice, intent1);
        });

        //游戏说明
        Button btn_introgame = (Button) findComponentById(ResourceTable.Id_introgame);
        btn_introgame.setClickedListener(component -> {
            CommonDialog cd = new CommonDialog(this);
            cd.setAutoClosable(true);
            DirectionalLayout dl = build_dl(0);
            ScrollView sv = new ScrollView(this);
            sv.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
            sv.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);

            Text content = new Text(this);
            content.setBackground(getButtonShape(this, 54, ResourceTable.Color_light_yellow, ResourceTable.Color_zongse));
            content.setTextSize(50);
            content.setMultipleLine(true);
            content.setText(
                    "[游戏玩法]\n" +
                            "开始游戏后，玩家自行选择喜欢的图片进行游\n" +
                            "戏，之后，选择难度，即将图片切分的行数和\n" +
                            "列数，并且可以指定可撤销的步数。\n" +
                            "开始挑战后，玩家点击空白格子相邻的切分小图\n" +
                            "和空白格子交换位置，直到拼出完整的图片\n\n\n" +
                            "[游戏背景]\n" +
                            "    华容道是古老的中国民间益智游戏，以其变化多端、\n" +
                            "百玩不厌的特点与魔方、独立钻石一起被国外\n" +
                            "智力专家并称为“智力游戏界的三个不可思议”。\n" +
                            "它与七巧板、九连环等中国传统益智玩具还有个代\n" +
                            "名词叫作“中国的难题”。\n" +
                            "    据《资治通鉴》注释中说“从此道可至华容也”。\n" +
                            "华容道原是中国古代的一个地名，相传当年曹操曾经败走\n" +
                            "此地。由于当时的华容道是一片沼泽，所以曹操大军要割草填\n" +
                            "地，不少士兵更惨被活埋，惨烈非常。\n" +
                            "    通过移动各个棋子，帮助曹操从\n" +
                            "初始位置移到棋盘最下方\n" +
                            "中部，从出口逃走。不允许跨越棋子，还要设法用\n" +
                            "最少的步数把\n" +
                            "曹操移到出口。曹操逃出华容道的最大障碍是关羽，\n" +
                            "关羽立马华容\n" +
                            "道，一夫当关，万夫莫开。关羽与曹操当然是解开这一\n" +
                            "游戏的关键。四个\n" +
                            "刘备军兵是最灵活的，也最容易对付，如何发挥他们的作用\n" +
                            "也要充分考虑周全。“华容道”有一个带二十个小方格的棋盘\n" +
                            "，代表华容道。\n"

            );
            sv.addComponent(content);
            dl.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
            dl.addComponent(sv);
            cd.setContentCustomComponent(dl);
            cd.show();
        });

        //作者信息
        Button btn_hhcinfo = (Button) findComponentById(ResourceTable.Id_hhcinfo);
        btn_hhcinfo.setClickedListener(component2 -> {
            CommonDialog cd2 = new CommonDialog(this);
            cd2.setAutoClosable(true);
            DirectionalLayout dl2 = build_dl(0);
            ScrollView sv2 = new ScrollView(this);
            sv2.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
            sv2.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);

            Text content2 = new Text(this);
            sv2.setBackground(getButtonShape(this, 54, ResourceTable.Color_light_yellow, ResourceTable.Color_zongse));
            content2.setTextSize(50);
            content2.setMultipleLine(true);
            content2.setText(
                    "作者：韩昊辰\n" +
                            "学校：重庆大学\n" +
                            "学院：计算机学院\n" +
                            "最后一次修改：2023/11/1\n"

            );
            sv2.addComponent(content2);
            dl2.addComponent(sv2);
            dl2.setWidth(ComponentContainer.LayoutConfig.MATCH_PARENT);
            cd2.setContentCustomComponent(dl2);
            cd2.show();
        });
    }



    //初始化线性布局
    public DirectionalLayout build_dl(int type){
        DirectionalLayout dl = new DirectionalLayout(this);
        if(type==0)//垂直
            dl.setOrientation(Component.VERTICAL);
        else //水平
            dl.setOrientation(Component.HORIZONTAL);
        dl.setHeight(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setWidth(ComponentContainer.LayoutConfig.MATCH_CONTENT);
        dl.setAlignment(LayoutAlignment.CENTER);
        return dl;
    }

    @Override
    public void onActive() {
        super.onActive();
    }

    @Override
    public void onForeground(Intent intent) {
        super.onForeground(intent);
    }
}
