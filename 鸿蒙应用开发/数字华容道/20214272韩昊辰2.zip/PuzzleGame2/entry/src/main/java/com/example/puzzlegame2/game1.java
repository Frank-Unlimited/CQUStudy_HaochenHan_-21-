package com.example.puzzlegame2;

import com.example.puzzlegame2.slice.game1Slice;
import ohos.aafwk.ability.Ability;
import ohos.aafwk.content.Intent;

public class game1 extends Ability {
    @Override
    public void onStart(Intent intent) {
        super.onStart(intent);
        super.setMainRoute(game1Slice.class.getName());
    }
}
