package com.example.puzzlegame2;

import ohos.agp.components.Component;
import ohos.agp.components.Image;

//记录点击过程中，单独一步的历史操作，需要维护：空白图片的内容和位置；空白图片以及对应component和点击的图片编号(nowi,nowj,empi,empj,emp)
public class History  {
    int nowi, nowj, empi , empj;
    Image emp;
    Component clickedimg;

    public Component getClickedimg() {
        return clickedimg;
    }

    public History(int nowi, int nowj, int empi, int empj, Image emp, Component clickedimg) {
        this.nowi = nowi;
        this.nowj = nowj;
        this.empi = empi;
        this.empj = empj;
        this.emp = emp;
        this.clickedimg = clickedimg;
    }

    public int getNowi() {
        return nowi;
    }

    public int getNowj() {
        return nowj;
    }

    public int getEmpi() {
        return empi;
    }

    public int getEmpj() {
        return empj;
    }

    public Image getEmp() {
        return emp;
    }
}
