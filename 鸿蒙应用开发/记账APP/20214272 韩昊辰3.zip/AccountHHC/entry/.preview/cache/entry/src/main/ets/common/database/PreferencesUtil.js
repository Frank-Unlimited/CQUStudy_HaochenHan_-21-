import dataPreferences from '@ohos:data.preferences';
const PREFERENCES_NAME = 'myPreferences'; // 首选项名字
const KEY_APP_FONT_SIZE = 'appFontSize'; // 首选项Key字段
export class PreferencesUtil {
    createFontPreferences(context) {
        globalThis.getFontPreferences = (() => {
            // 获取首选项实例
            let preferences = dataPreferences.getPreferences(context, PREFERENCES_NAME);
            return preferences;
        });
        // let fontPreferences: Function = (() => {
        //   let preferences: Promise<dataPreferences.Preferences> = dataPreferences.getPreferences(context,
        //     PREFERENCES_NAME);
        //   return preferences;
        // });
        // GlobalContext.getContext().setObject('getFontPreferences', fontPreferences);
    }
}
export default new PreferencesUtil();
//# sourceMappingURL=PreferencesUtil.js.map