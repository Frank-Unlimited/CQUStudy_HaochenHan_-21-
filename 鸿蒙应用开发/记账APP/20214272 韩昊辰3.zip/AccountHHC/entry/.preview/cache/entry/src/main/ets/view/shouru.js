import DataModel from '@bundle:com.example.accounthhc/entry/ets/viewmodule/DataModule';
import ItemData from '@bundle:com.example.accounthhc/entry/ets/viewmodule/ItemData';
import Luru from '@bundle:com.example.accounthhc/entry/ets/view/Luru';
import RecordData from '@bundle:com.example.accounthhc/entry/ets/viewmodule/RecordData';
import AccountTable from '@bundle:com.example.accounthhc/entry/ets/common/database/tables/AccountTable';
import Prompt from '@ohos:prompt';
import router from '@ohos:router';
function truncateDecimalString(input) {
    const parts = input.split('.');
    // 如果有小数部分
    if (parts.length === 2) {
        // 截断小数部分至两位
        const truncatedDecimal = parts[1].substring(0, 2);
        // 组合整数部分和截断后的小数部分
        return `${parts[0]}.${truncatedDecimal}`;
    }
    // 如果没有小数部分，返回原始字符串
    return input;
}
export default class shouru extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__input_money = new ObservedPropertySimplePU("0.00", this, "input_money");
        this.__curentIndex = new ObservedPropertySimplePU(-1.0, this, "curentIndex");
        this.__leixing = new ObservedPropertyObjectPU(new ItemData("其他", { "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }), this, "leixing");
        this.__monney = new ObservedPropertySimplePU(0.00, this, "monney");
        this.__beizhu = new ObservedPropertySimplePU("", this, "beizhu");
        this.__isExpanded = new ObservedPropertySimplePU(false, this, "isExpanded");
        this.__accounts = this.initializeConsume("accounts", "accounts");
        this.__selectedDate_year = new ObservedPropertySimplePU(2023, this, "selectedDate_year");
        this.__selectedDate_month = new ObservedPropertySimplePU(11, this, "selectedDate_month");
        this.__selectedDate_day = new ObservedPropertySimplePU(20, this, "selectedDate_day");
        this.selectedDate = new Date();
        this.AccountTable = new AccountTable(() => { });
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.input_money !== undefined) {
            this.input_money = params.input_money;
        }
        if (params.curentIndex !== undefined) {
            this.curentIndex = params.curentIndex;
        }
        if (params.leixing !== undefined) {
            this.leixing = params.leixing;
        }
        if (params.monney !== undefined) {
            this.monney = params.monney;
        }
        if (params.beizhu !== undefined) {
            this.beizhu = params.beizhu;
        }
        if (params.isExpanded !== undefined) {
            this.isExpanded = params.isExpanded;
        }
        if (params.selectedDate_year !== undefined) {
            this.selectedDate_year = params.selectedDate_year;
        }
        if (params.selectedDate_month !== undefined) {
            this.selectedDate_month = params.selectedDate_month;
        }
        if (params.selectedDate_day !== undefined) {
            this.selectedDate_day = params.selectedDate_day;
        }
        if (params.selectedDate !== undefined) {
            this.selectedDate = params.selectedDate;
        }
        if (params.AccountTable !== undefined) {
            this.AccountTable = params.AccountTable;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__input_money.purgeDependencyOnElmtId(rmElmtId);
        this.__curentIndex.purgeDependencyOnElmtId(rmElmtId);
        this.__leixing.purgeDependencyOnElmtId(rmElmtId);
        this.__monney.purgeDependencyOnElmtId(rmElmtId);
        this.__beizhu.purgeDependencyOnElmtId(rmElmtId);
        this.__isExpanded.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate_year.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate_month.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate_day.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__input_money.aboutToBeDeleted();
        this.__curentIndex.aboutToBeDeleted();
        this.__leixing.aboutToBeDeleted();
        this.__monney.aboutToBeDeleted();
        this.__beizhu.aboutToBeDeleted();
        this.__isExpanded.aboutToBeDeleted();
        this.__accounts.aboutToBeDeleted();
        this.__selectedDate_year.aboutToBeDeleted();
        this.__selectedDate_month.aboutToBeDeleted();
        this.__selectedDate_day.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get input_money() {
        return this.__input_money.get();
    }
    set input_money(newValue) {
        this.__input_money.set(newValue);
    }
    get curentIndex() {
        return this.__curentIndex.get();
    }
    set curentIndex(newValue) {
        this.__curentIndex.set(newValue);
    }
    get leixing() {
        return this.__leixing.get();
    }
    set leixing(newValue) {
        this.__leixing.set(newValue);
    }
    get monney() {
        return this.__monney.get();
    }
    set monney(newValue) {
        this.__monney.set(newValue);
    }
    get beizhu() {
        return this.__beizhu.get();
    }
    set beizhu(newValue) {
        this.__beizhu.set(newValue);
    }
    get isExpanded() {
        return this.__isExpanded.get();
    }
    set isExpanded(newValue) {
        this.__isExpanded.set(newValue);
    }
    get accounts() {
        return this.__accounts.get();
    }
    set accounts(newValue) {
        this.__accounts.set(newValue);
    }
    get selectedDate_year() {
        return this.__selectedDate_year.get();
    }
    set selectedDate_year(newValue) {
        this.__selectedDate_year.set(newValue);
    }
    get selectedDate_month() {
        return this.__selectedDate_month.get();
    }
    set selectedDate_month(newValue) {
        this.__selectedDate_month.set(newValue);
    }
    get selectedDate_day() {
        return this.__selectedDate_day.get();
    }
    set selectedDate_day(newValue) {
        this.__selectedDate_day.set(newValue);
    }
    // aboutToAppear(){
    //   this.AccountTable.getRdbStore(() => {});
    // }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("view/shouru.ets(55:5)");
            Stack.alignContent(Alignment.Bottom);
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("view/shouru.ets(56:7)");
            Column.height('100%');
            Column.width('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Grid.create();
            Grid.debugLine("view/shouru.ets(57:9)");
            Grid.columnsTemplate('2fr 1fr 2fr');
            Grid.rowsTemplate('1fr 1fr 1fr 1fr');
            if (!isInitialRender) {
                Grid.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                {
                    const isLazyCreate = true && (Grid.willUseProxy() === true);
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        GridItem.create(deepRenderFunction, isLazyCreate);
                        GridItem.onClick(() => {
                            this.curentIndex = (this.curentIndex == -1) ? index : -1;
                            this.leixing = item;
                            this.isExpanded = !this.isExpanded;
                        });
                        GridItem.debugLine("view/shouru.ets(59:13)");
                        if (!isInitialRender) {
                            GridItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        GridItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("view/shouru.ets(60:15)");
                            Context.animation({
                                duration: 300,
                                curve: Curve.EaseOut,
                                iterations: 1
                            });
                            Column.width(70);
                            Column.height(80);
                            Column.backgroundColor((this.curentIndex == index && this.isExpanded == true) ? '#007DFF' : { "id": 16777227, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            Column.border({
                                radius: { topLeft: 20, topRight: 20, bottomLeft: 20, bottomRight: 20 }
                            });
                            Context.animation(null);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("view/shouru.ets(61:17)");
                            Row.width(50);
                            Row.height(50);
                            Row.alignItems(VerticalAlign.Center);
                            Row.justifyContent(FlexAlign.Center);
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.img);
                            Image.debugLine("view/shouru.ets(62:19)");
                            Image.objectFit(ImageFit.Auto);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Row.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.title);
                            Text.debugLine("view/shouru.ets(69:17)");
                            Text.fontSize(15);
                            Text.margin({ top: 10 });
                            Text.fontColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        GridItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Column.create();
                            Column.debugLine("view/shouru.ets(60:15)");
                            Context.animation({
                                duration: 300,
                                curve: Curve.EaseOut,
                                iterations: 1
                            });
                            Column.width(70);
                            Column.height(80);
                            Column.backgroundColor((this.curentIndex == index && this.isExpanded == true) ? '#007DFF' : { "id": 16777227, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            Column.border({
                                radius: { topLeft: 20, topRight: 20, bottomLeft: 20, bottomRight: 20 }
                            });
                            Context.animation(null);
                            if (!isInitialRender) {
                                Column.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("view/shouru.ets(61:17)");
                            Row.width(50);
                            Row.height(50);
                            Row.alignItems(VerticalAlign.Center);
                            Row.justifyContent(FlexAlign.Center);
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create(item.img);
                            Image.debugLine("view/shouru.ets(62:19)");
                            Image.objectFit(ImageFit.Auto);
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Row.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.title);
                            Text.debugLine("view/shouru.ets(69:17)");
                            Text.fontSize(15);
                            Text.margin({ top: 10 });
                            Text.fontColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Column.pop();
                        GridItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, DataModel.getFirstGridData(), forEachItemGenFunction, (item) => JSON.stringify(item), true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Grid.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // if(this.isExpanded){
            Column.create();
            Column.debugLine("view/shouru.ets(100:7)");
            Context.animation({
                duration: 300,
                curve: Curve.EaseOut,
                iterations: 1
            });
            // if(this.isExpanded){
            Column.backgroundColor({ "id": 16777223, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            // if(this.isExpanded){
            Column.border({ radius: 5, color: Color.Blue });
            // if(this.isExpanded){
            Column.margin({ bottom: 0 });
            // if(this.isExpanded){
            Column.height(this.isExpanded ? 400 : 0);
            // if(this.isExpanded){
            Column.width('100%');
            Context.animation(null);
            if (!isInitialRender) {
                // if(this.isExpanded){
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/shouru.ets(101:9)");
            Row.backgroundColor({ "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            Row.width('85%');
            Row.height(45);
            Row.border({ radius: 10 });
            Row.margin({ top: 10 });
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.leixing.img);
            Image.debugLine("view/shouru.ets(102:11)");
            Image.width(30);
            Image.height(30);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("为【" + this.leixing.title + "】类添加收入记录");
            Text.debugLine("view/shouru.ets(106:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new Luru(this, {
                        input_money: this.__input_money,
                        monney: this.__monney,
                        beizhu: this.__beizhu,
                        selectedDate_year: this.__selectedDate_year,
                        selectedDate_month: this.__selectedDate_month,
                        selectedDate_day: this.__selectedDate_day,
                        isExpanded: this.__isExpanded
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/shouru.ets(125:9)");
            Row.margin({ top: 10, bottom: 20 });
            Row.width('90%');
            Row.justifyContent(FlexAlign.SpaceEvenly);
            Row.alignItems(VerticalAlign.Center);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('确认', { type: ButtonType.Normal, stateEffect: true });
            Button.debugLine("view/shouru.ets(126:11)");
            Button.borderRadius(8);
            Button.backgroundColor(0x317aff);
            Button.width(150);
            Button.onClick(() => {
                //检查金额输入
                let val_num = parseFloat(truncateDecimalString(this.input_money));
                if (val_num >= 0) {
                    this.monney = val_num;
                    //存数据库
                    AlertDialog.show({
                        title: "确认数据",
                        message: "金额: " + this.monney + "" +
                            "\n备注：" + this.beizhu +
                            "\n日期: " + this.selectedDate_year + "年" + this.selectedDate_month + "月" + this.selectedDate_day + "日",
                        autoCancel: true,
                        confirm: {
                            value: '确认',
                            action: () => {
                                let date = new Date(this.selectedDate_year, this.selectedDate_month, this.selectedDate_day);
                                let newRecordDate = new RecordData(this.monney, date, this.beizhu, 1, new Date(), { leixing: this.leixing });
                                this.AccountTable.insertData(newRecordDate, (id) => {
                                    newRecordDate.id = id;
                                    this.accounts.push(newRecordDate);
                                });
                                Prompt.showToast({
                                    message: "添加成功",
                                    duration: 2000
                                });
                                router.pushUrl({
                                    url: 'pages/Index'
                                }, router.RouterMode.Single);
                            }
                        },
                        cancel: () => {
                            console.info('Closed callbacks');
                        }
                    });
                }
                else {
                    AlertDialog.show({
                        title: "输入的金额非法",
                        message: "输入：" + this.monney + "请输入不小于零的数字",
                        autoCancel: true,
                        confirm: {
                            value: '确认',
                            action: () => {
                                console.info('Button-clicking callback');
                            }
                        },
                        cancel: () => {
                            console.info('Closed callbacks');
                        }
                    }).backgroundColor(0x317aff);
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('取消', { type: ButtonType.Normal, stateEffect: true });
            Button.debugLine("view/shouru.ets(184:11)");
            Button.borderRadius(8);
            Button.backgroundColor(Color.Gray);
            Button.width(150);
            Button.onClick(() => {
                this.isExpanded = !this.isExpanded;
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Row.pop();
        // if(this.isExpanded){
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=shouru.js.map