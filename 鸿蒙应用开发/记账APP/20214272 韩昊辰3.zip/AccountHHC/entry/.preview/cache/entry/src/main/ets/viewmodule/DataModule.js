/*
 * Copyright (c) 2022 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import ItemData from '@bundle:com.example.accounthhc/entry/ets/viewmodule/ItemData';
/**
 * Binds data to components and provides interfaces.
 */
export class MainViewModel {
    // /**
    //  * Get swiper image data.
    //  *
    //  * @return {Array<Resource>} swiperImages.
    //  */
    // getSwiperImages(): Array<Resource> {
    //   let swiperImages: Resource[] = [
    //   $r('app.media.fig1'),
    //   $r('app.media.fig2'),
    //   $r('app.media.fig3'),
    //   $r('app.media.fig4')
    //   ];
    //   return swiperImages;
    // }
    /**
     * Get data of the first grid.
     *
     * @return {Array<PageResource>} firstGridData.
     */
    getFirstGridData() {
        let firstGridData = [
            // new ItemData($r('app.string.my_love'), $r('app.media.love')),
            new ItemData("工资", { "id": 16777231, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'gongzi'),
            new ItemData('兼职', { "id": 16777244, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'jianzhi'),
            new ItemData('投资', { "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'touzi'),
            new ItemData('其他', { "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'qita')
        ];
        return firstGridData;
    }
    getSecondGridData() {
        let firstGridData = [
            // new ItemData($r('app.string.my_love'), $r('app.media.love')),
            new ItemData('购物', { "id": 16777249, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'gouwu'),
            new ItemData('餐饮', { "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'canyin'),
            new ItemData('日用', { "id": 16777255, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'riyong'),
            new ItemData('运动', { "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'yundong'),
            new ItemData('娱乐', { "id": 16777232, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'yule'),
            new ItemData('教育', { "id": 16777245, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'jiaoyu'),
            new ItemData('出行', { "id": 16777243, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'chuxing'),
            new ItemData('数码', { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'shuma'),
            new ItemData('住房', { "id": 16777247, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'zhufang'),
            new ItemData('医疗', { "id": 16777257, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'yiliao'),
            new ItemData('其他', { "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" }, 'qita')
        ];
        return firstGridData;
    }
}
export default new MainViewModel();
//# sourceMappingURL=DataModule.js.map