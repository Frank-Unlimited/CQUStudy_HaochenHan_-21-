import UIAbility from '@ohos:app.ability.UIAbility';
import hilog from '@ohos:hilog';
import dataPreferences from '@ohos:data.preferences';
export default class EntryAbility extends UIAbility {
    onCreate(want, launchParam) {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
        //获取Preferences实例
        try {
            dataPreferences.getPreferences(this.context, 'mystore', (err, preferences) => {
                if (err) {
                    console.error(`Failed to get preferences. Code:${err.code},message:${err.message}`);
                    return;
                }
                console.info('Succeeded in getting preferences.');
                // 进行相关数据操作
                //读取数据
                try {
                    preferences.get('userName', 'hhcTableName', (err, val) => {
                        if (err) {
                            console.error(`Failed to get value of 'startup'. Code:${err.code}, message:${err.message}`);
                            return;
                        }
                        console.info(`Succeeded in getting value of 'startup'. val: ${val}.`);
                    });
                }
                catch (err) {
                    console.error(`Failed to get value of 'startup'. Code:${err.code}, message:${err.message}`);
                }
            });
        }
        catch (err) {
            console.error(`Failed to get preferences. Code:${err.code},message:${err.message}`);
        }
    }
    onDestroy() {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage) {
        // Main window is created, set main page for this ability
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageCreate');
        windowStage.loadContent('pages/Index', (err, data) => {
            var _a, _b;
            if (err.code) {
                hilog.error(0x0000, 'testTag', 'Failed to load the content. Cause: %{public}s', (_a = JSON.stringify(err)) !== null && _a !== void 0 ? _a : '');
                return;
            }
            hilog.info(0x0000, 'testTag', 'Succeeded in loading the content. Data: %{public}s', (_b = JSON.stringify(data)) !== null && _b !== void 0 ? _b : '');
        });
    }
    onWindowStageDestroy() {
        // Main window is destroyed, release UI related resources
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground() {
        // Ability has brought to foreground
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
    }
    onBackground() {
        // Ability has back to background
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
    }
}
//# sourceMappingURL=EntryAbility.js.map