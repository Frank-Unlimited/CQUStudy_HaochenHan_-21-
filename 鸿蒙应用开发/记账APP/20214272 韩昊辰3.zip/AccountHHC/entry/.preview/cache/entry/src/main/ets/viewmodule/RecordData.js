import ItemData from '@bundle:com.example.accounthhc/entry/ets/viewmodule/ItemData';
export default class RecordData {
    constructor(money, Date, beizhu, IO, buildTime, opt) {
        this.id = -1;
        this.buildTime = buildTime.toTimeString();
        if (opt.leixing != null) {
            this.leixing = opt.leixing;
            this.leixing_str = opt.leixing.title;
            this.leixing_icon = opt.leixing.imgsrc;
        }
        else {
            this.leixing_str = opt.leixing_str;
            this.leixing_icon = opt.leixing_icon;
            let resourcestr = 'app.media.' + opt.leixing_str;
            this.leixing = new ItemData(opt.leixing_str, $r(resourcestr));
        }
        this.money = money;
        this.beizhu = beizhu;
        this.IO = IO;
        this.others = opt.others;
        this.year = Date.getFullYear().toString();
        this.month = Date.getMonth().toString();
        this.day = Date.getDay().toString();
    }
}
//# sourceMappingURL=RecordData.js.map