/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import relationalStore from '@ohos:data.relationalStore';
import ItemData from '@bundle:com.example.accounthhc/entry/ets/viewmodule/ItemData';
import Rdb from '@bundle:com.example.accounthhc/entry/ets/common/database/Rdb';
export default class AccountTable {
    constructor(callback = () => {
    }) {
        this.tableName = 'hhcTableName';
        this.accountTable = new Rdb(this.tableName, 'CREATE TABLE IF NOT EXISTS hhcTableName(id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
            'leixing_str TEXT,leixing_icon TEXT, money INTEGER, year INTEGER, month INTEGER, day INTEGER, beizhu TEXT, IO INTEGER, buildTime TEXT)', ['id', 'leixing_str', 'leixing_icon', 'money', 'year', 'month', 'day', 'beizhu', 'IO', 'buildTime']);
        this.accountTable.getRdbStore(callback);
    }
    getRdbStore(callback = () => {
    }) {
        this.accountTable.getRdbStore(callback);
    }
    insertData(account, callback) {
        const valueBucket = generateBucket(account);
        this.accountTable.insertData(valueBucket, callback);
    }
    deleteData(account, callback) {
        let predicates = new relationalStore.RdbPredicates(this.tableName);
        predicates.equalTo('id', account.id);
        this.accountTable.deleteData(predicates, callback);
    }
    updateData(account, callback) {
        const valueBucket = generateBucket(account);
        let predicates = new relationalStore.RdbPredicates(this.tableName);
        predicates.equalTo('id', account.id);
        this.accountTable.updateData(predicates, valueBucket, callback);
    }
    //查询，支持按照 支出/收入，年，月，日，类型，金额大小，备注 查询
    query_default(callback, isAll = true, IO, DATE, money, leixing, beizhu) {
        let predicates = new relationalStore.RdbPredicates(this.tableName);
        if (!isAll) {
            if (IO != null)
                predicates = this.query_zhichu(IO, predicates);
            if (DATE != null)
                predicates = this.query_date(DATE[0], DATE[1], DATE[2], DATE[3], DATE[4], DATE[5], predicates);
            if (money != null)
                predicates = this.query_money(money[0], money[1], predicates);
            if (leixing != null)
                predicates = this.query_leixing(leixing, predicates);
            if (beizhu != null)
                predicates = this.query_beizhu(beizhu, predicates);
        }
        this.query(callback, predicates);
    }
    //按照 支出收入
    query_zhichu(IO, predicates) {
        predicates.and().equalTo('IO', IO);
        return predicates;
    }
    // 按照年月日
    query_date(low_year, low_month, low_day, high_year, high_month, high_day, predicates) {
        predicates
            .and()
            .between("year", low_year, high_year).and()
            .between("month", low_month, high_month).and()
            .between("day", low_day, high_day);
        return predicates;
    }
    // 按照金额
    query_money(low_money, high_money, predicates) {
        predicates
            .and()
            .between("money", low_money, high_money);
        return predicates;
    }
    //按类型
    query_leixing(leixing, predicates) {
        predicates.and().equalTo("leixing_str", leixing);
        return predicates;
    }
    //按备注
    query_beizhu(beizhu, predicates) {
        predicates.and().contains("beizhu", beizhu);
        return predicates;
    }
    query(callback, predicates) {
        // let predicates = new relationalStore.RdbPredicates(this.tableName);
        // if (!isAll) {
        //   //predicates.equalTo('amount', amount);
        // }
        this.accountTable.query(predicates, (resultSet) => {
            let count = resultSet.rowCount;
            if (count === 0 || typeof count === 'string') {
                console.log('[Debug.AccountTable]' + 'Query no results!');
                callback([]);
            }
            else {
                resultSet.goToFirstRow();
                const result = [];
                for (let i = 0; i < count; i++) {
                    let tmp = {
                        // id: 0, accountType: 0, typeText: '', amount: 0
                        id: 0,
                        leixing: new ItemData,
                        money: 0,
                        beizhu: '',
                        IO: 0,
                        buildTime: "",
                        leixing_str: "", leixing_icon: "", year: "", month: "", day: ""
                    };
                    tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
                    tmp.leixing_str = resultSet.getString(resultSet.getColumnIndex('leixing_str'));
                    tmp.leixing_icon = resultSet.getString(resultSet.getColumnIndex('leixing_icon'));
                    tmp.money = resultSet.getDouble(resultSet.getColumnIndex('money'));
                    tmp.year = resultSet.getString(resultSet.getColumnIndex('year'));
                    tmp.month = resultSet.getString(resultSet.getColumnIndex('month'));
                    tmp.day = resultSet.getString(resultSet.getColumnIndex('day'));
                    tmp.beizhu = resultSet.getString(resultSet.getColumnIndex('beizhu'));
                    let resourcestr = 'app.media.' + tmp.leixing_icon;
                    tmp.leixing = new ItemData(tmp.leixing_str, $r(resourcestr));
                    tmp.IO = resultSet.getDouble(resultSet.getColumnIndex('IO'));
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);
            }
        });
    }
}
function generateBucket(account) {
    let obj = {};
    //  ['id','leixing_str','leixing_icon','money','year','month','day','beizhu','IO','buildTime']
    obj.leixing_str = account.leixing_str;
    obj.leixing_icon = account.leixing_icon;
    obj.money = account.money;
    obj.year = account.year;
    obj.month = account.month;
    obj.day = account.day;
    obj.beizhu = account.beizhu;
    obj.IO = account.IO;
    obj.buildTime = account.buildTime;
    // obj.typeText = account.typeText;
    // obj.amount = account.amount;
    return obj;
}
//# sourceMappingURL=AccountTable.js.map