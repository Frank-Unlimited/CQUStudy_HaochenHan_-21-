import Prompt from '@ohos:prompt';
import CommonConstants from '@bundle:com.example.accounthhc/entry/ets/common/constants/CommonConstants';
import AccountTable from '@bundle:com.example.accounthhc/entry/ets/common/database/tables/AccountTable';
let comp_shunxu = CommonConstants.COMP_SHENGXU;
let comp_type = CommonConstants.COMP_DATE_TYPE;
//排序函数
function compareRecords(a, b) {
    console.log("排序函数");
    let returnCode1 = 1, returnCode2 = -1;
    if (comp_shunxu == null || comp_shunxu == CommonConstants.COMP_SHENGXU) {
        returnCode1 = -1;
        returnCode2 = 1;
    }
    //日期
    if (comp_type == CommonConstants.COMP_DATE_TYPE) {
        const yearA = parseInt(a.year);
        console.log("yearA " + yearA);
        const yearB = parseInt(b.year);
        const monthA = parseInt(a.month);
        const monthB = parseInt(b.month);
        const dayA = parseInt(a.day);
        const dayB = parseInt(b.day);
        if (yearA < yearB) {
            return returnCode2;
        }
        else if (yearA > yearB) {
            return returnCode1;
        }
        else {
            if (monthA != monthB) {
                return monthA > monthB ? returnCode1 : returnCode2;
            }
            else {
                return dayA > dayB ? returnCode1 : returnCode2;
            }
        }
        return 0;
    }
}
export default class RecordClass extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__accounts = new SynchedPropertyObjectTwoWayPU(params.accounts, this, "accounts");
        this.__isEdit = new ObservedPropertySimplePU(false, this, "isEdit");
        this.__isInsert = new ObservedPropertySimplePU(false, this, "isInsert");
        this.__index = new ObservedPropertySimplePU(-1, this, "index");
        this.deleteList = [];
        this.AccountTable = new AccountTable(() => { });
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.isEdit !== undefined) {
            this.isEdit = params.isEdit;
        }
        if (params.isInsert !== undefined) {
            this.isInsert = params.isInsert;
        }
        if (params.index !== undefined) {
            this.index = params.index;
        }
        if (params.deleteList !== undefined) {
            this.deleteList = params.deleteList;
        }
        if (params.AccountTable !== undefined) {
            this.AccountTable = params.AccountTable;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__accounts.purgeDependencyOnElmtId(rmElmtId);
        this.__isEdit.purgeDependencyOnElmtId(rmElmtId);
        this.__isInsert.purgeDependencyOnElmtId(rmElmtId);
        this.__index.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__accounts.aboutToBeDeleted();
        this.__isEdit.aboutToBeDeleted();
        this.__isInsert.aboutToBeDeleted();
        this.__index.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get accounts() {
        return this.__accounts.get();
    }
    set accounts(newValue) {
        this.__accounts.set(newValue);
    }
    get isEdit() {
        return this.__isEdit.get();
    }
    set isEdit(newValue) {
        this.__isEdit.set(newValue);
    }
    get isInsert() {
        return this.__isInsert.get();
    }
    set isInsert(newValue) {
        this.__isInsert.set(newValue);
    }
    get index() {
        return this.__index.get();
    }
    set index(newValue) {
        this.__index.set(newValue);
    }
    deleteListItem() {
        for (let i = 0; i < this.deleteList.length; i++) {
            let index = this.accounts.indexOf(this.deleteList[i]);
            this.accounts.splice(index, 1);
            this.AccountTable.deleteData(this.deleteList[i], () => {
            });
        }
        this.deleteList = [];
        this.isEdit = false;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/Record.ets(61:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 12 });
            Column.debugLine("view/Record.ets(62:7)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("view/Record.ets(63:9)");
            Column.width("90%");
            Column.backgroundColor({ "id": 16777222, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            Column.height(150);
            Column.border({ radius: 20 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("记录");
            Text.debugLine("view/Record.ets(64:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 5 });
            Row.debugLine("view/Record.ets(71:9)");
            Row.width("90%");
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("排序方式");
            Text.debugLine("view/Record.ets(72:11)");
            Text.fontSize(13);
            Text.width(80);
            Text.onClick(() => {
                Prompt.showToast({
                    message: "降序"
                });
                console.log("排序前");
                comp_shunxu = CommonConstants.COMP_JIANGXU;
                this.accounts.sort(compareRecords);
                // this.accounts.reverse()
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            Image.debugLine("view/Record.ets(85:11)");
            Image.width(24);
            Image.align(Alignment.End);
            Image.onClick(() => {
                this.isEdit = !this.isEdit;
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/Record.ets(97:9)");
            Row.width('100%');
            Row.padding({ left: 12, right: 12 });
            Row.margin({ top: 4 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 1 });
            List.debugLine("view/Record.ets(98:11)");
            List.width('100%');
            List.borderRadius(24);
            List.backgroundColor(Color.White);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.width('100%');
                        ListItem.height(56);
                        ListItem.onClick(() => {
                        });
                        ListItem.debugLine("view/Record.ets(100:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("view/Record.ets(101:17)");
                            Row.width('100%');
                            Row.padding({ left: 12, right: 12 });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create({ "id": 16777255, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            Image.debugLine("view/Record.ets(102:19)");
                            Image.width(40);
                            Image.aspectRatio(1);
                            Image.margin({ right: 16 });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.leixing_str);
                            Text.debugLine("view/Record.ets(107:19)");
                            Text.height(22);
                            Text.fontSize(16);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.beizhu);
                            Text.debugLine("view/Record.ets(111:19)");
                            Text.height(22);
                            Text.width(150);
                            Text.fontSize(13);
                            Text.fontColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            Text.maxLines(1);
                            Text.margin({ left: 10 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Blank.create();
                            Blank.debugLine("view/Record.ets(120:19)");
                            Blank.layoutWeight(1);
                            if (!isInitialRender) {
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (!this.isEdit) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item.IO === 0 ? '-' + item.money : '+' + item.money);
                                        Text.debugLine("view/Record.ets(124:21)");
                                        Text.fontSize(16);
                                        Text.fontColor(item.IO === 0 ? "#FFE84826" : '#FF007DFF');
                                        Text.align(Alignment.End);
                                        Text.flexGrow(1);
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Row.create();
                                        Row.debugLine("view/Record.ets(130:21)");
                                        Row.align(Alignment.End);
                                        Row.flexGrow(1);
                                        Row.justifyContent(FlexAlign.End);
                                        if (!isInitialRender) {
                                            Row.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Toggle.create({ type: ToggleType.Checkbox });
                                        Toggle.debugLine("view/Record.ets(131:23)");
                                        Toggle.onChange((isOn) => {
                                            if (isOn) {
                                                this.deleteList.push(item);
                                            }
                                            else {
                                                let index = this.deleteList.indexOf(item);
                                                this.deleteList.splice(index, 1);
                                            }
                                        });
                                        if (!isInitialRender) {
                                            Toggle.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Toggle.pop();
                                    Row.pop();
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("view/Record.ets(101:17)");
                            Row.width('100%');
                            Row.padding({ left: 12, right: 12 });
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Image.create({ "id": 16777255, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            Image.debugLine("view/Record.ets(102:19)");
                            Image.width(40);
                            Image.aspectRatio(1);
                            Image.margin({ right: 16 });
                            if (!isInitialRender) {
                                Image.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.leixing_str);
                            Text.debugLine("view/Record.ets(107:19)");
                            Text.height(22);
                            Text.fontSize(16);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.beizhu);
                            Text.debugLine("view/Record.ets(111:19)");
                            Text.height(22);
                            Text.width(150);
                            Text.fontSize(13);
                            Text.fontColor({ "id": 16777225, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            Text.maxLines(1);
                            Text.margin({ left: 10 });
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Blank.create();
                            Blank.debugLine("view/Record.ets(120:19)");
                            Blank.layoutWeight(1);
                            if (!isInitialRender) {
                                Blank.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Blank.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            If.create();
                            if (!this.isEdit) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Text.create(item.IO === 0 ? '-' + item.money : '+' + item.money);
                                        Text.debugLine("view/Record.ets(124:21)");
                                        Text.fontSize(16);
                                        Text.fontColor(item.IO === 0 ? "#FFE84826" : '#FF007DFF');
                                        Text.align(Alignment.End);
                                        Text.flexGrow(1);
                                        if (!isInitialRender) {
                                            Text.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Text.pop();
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Row.create();
                                        Row.debugLine("view/Record.ets(130:21)");
                                        Row.align(Alignment.End);
                                        Row.flexGrow(1);
                                        Row.justifyContent(FlexAlign.End);
                                        if (!isInitialRender) {
                                            Row.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    this.observeComponentCreation((elmtId, isInitialRender) => {
                                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                        Toggle.create({ type: ToggleType.Checkbox });
                                        Toggle.debugLine("view/Record.ets(131:23)");
                                        Toggle.onChange((isOn) => {
                                            if (isOn) {
                                                this.deleteList.push(item);
                                            }
                                            else {
                                                let index = this.deleteList.indexOf(item);
                                                this.deleteList.splice(index, 1);
                                            }
                                        });
                                        if (!isInitialRender) {
                                            Toggle.pop();
                                        }
                                        ViewStackProcessor.StopGetAccessRecording();
                                    });
                                    Toggle.pop();
                                    Row.pop();
                                });
                            }
                            if (!isInitialRender) {
                                If.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        If.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.accounts, forEachItemGenFunction);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("到底了");
            Text.debugLine("view/Record.ets(161:11)");
            Text.fontSize(10);
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.isEdit) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Button.createWithChild();
                        Button.debugLine("view/Record.ets(175:9)");
                        Button.width(48);
                        Button.height(48);
                        Button.markAnchor({ x: 24, y: 0 });
                        Button.position({ x: '50%', y: '90%' });
                        Button.onClick(() => {
                            Prompt.showToast({
                                message: 'nih'
                            });
                            this.deleteListItem();
                            Prompt.showToast({
                                message: "删除成功"
                            });
                        });
                        if (!isInitialRender) {
                            Button.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
                        Image.debugLine("view/Record.ets(176:11)");
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Button.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=Record.js.map