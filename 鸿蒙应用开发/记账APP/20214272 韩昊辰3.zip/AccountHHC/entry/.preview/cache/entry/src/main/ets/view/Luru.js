export default class Luru extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__input_money = new SynchedPropertySimpleTwoWayPU(params.input_money, this, "input_money");
        this.__monney = new SynchedPropertySimpleTwoWayPU(params.monney, this, "monney");
        this.__beizhu = new SynchedPropertySimpleTwoWayPU(params.beizhu, this, "beizhu");
        this.selectedDate = undefined;
        this.__isExpanded = new SynchedPropertySimpleTwoWayPU(params.isExpanded, this, "isExpanded");
        this.TextInputController1 = new TextInputController();
        this.TextInputController2 = new TextInputController();
        this.CustomDialogController = undefined;
        this.selectedDateInPicker = new Date();
        this.__selectedDateString = new ObservedPropertySimplePU("今天", this, "selectedDateString");
        this.__selectedDate_year = new SynchedPropertySimpleTwoWayPU(params.selectedDate_year, this, "selectedDate_year");
        this.__selectedDate_month = new SynchedPropertySimpleTwoWayPU(params.selectedDate_month, this, "selectedDate_month");
        this.__selectedDate_day = new SynchedPropertySimpleTwoWayPU(params.selectedDate_day, this, "selectedDate_day");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selectedDate !== undefined) {
            this.selectedDate = params.selectedDate;
        }
        if (params.TextInputController1 !== undefined) {
            this.TextInputController1 = params.TextInputController1;
        }
        if (params.TextInputController2 !== undefined) {
            this.TextInputController2 = params.TextInputController2;
        }
        if (params.CustomDialogController !== undefined) {
            this.CustomDialogController = params.CustomDialogController;
        }
        if (params.selectedDateInPicker !== undefined) {
            this.selectedDateInPicker = params.selectedDateInPicker;
        }
        if (params.selectedDateString !== undefined) {
            this.selectedDateString = params.selectedDateString;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__input_money.purgeDependencyOnElmtId(rmElmtId);
        this.__monney.purgeDependencyOnElmtId(rmElmtId);
        this.__beizhu.purgeDependencyOnElmtId(rmElmtId);
        this.__isExpanded.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDateString.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate_year.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate_month.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedDate_day.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__input_money.aboutToBeDeleted();
        this.__monney.aboutToBeDeleted();
        this.__beizhu.aboutToBeDeleted();
        this.__isExpanded.aboutToBeDeleted();
        this.__selectedDateString.aboutToBeDeleted();
        this.__selectedDate_year.aboutToBeDeleted();
        this.__selectedDate_month.aboutToBeDeleted();
        this.__selectedDate_day.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get input_money() {
        return this.__input_money.get();
    }
    set input_money(newValue) {
        this.__input_money.set(newValue);
    }
    get monney() {
        return this.__monney.get();
    }
    set monney(newValue) {
        this.__monney.set(newValue);
    }
    get beizhu() {
        return this.__beizhu.get();
    }
    set beizhu(newValue) {
        this.__beizhu.set(newValue);
    }
    get isExpanded() {
        return this.__isExpanded.get();
    }
    set isExpanded(newValue) {
        this.__isExpanded.set(newValue);
    }
    setController(ctr) {
        this.CustomDialogController = ctr;
    }
    get selectedDateString() {
        return this.__selectedDateString.get();
    }
    set selectedDateString(newValue) {
        this.__selectedDateString.set(newValue);
    }
    get selectedDate_year() {
        return this.__selectedDate_year.get();
    }
    set selectedDate_year(newValue) {
        this.__selectedDate_year.set(newValue);
    }
    get selectedDate_month() {
        return this.__selectedDate_month.get();
    }
    set selectedDate_month(newValue) {
        this.__selectedDate_month.set(newValue);
    }
    get selectedDate_day() {
        return this.__selectedDate_day.get();
    }
    set selectedDate_day(newValue) {
        this.__selectedDate_day.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 1 });
            Column.debugLine("view/Luru.ets(24:5)");
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/Luru.ets(25:7)");
            Row.justifyContent(FlexAlign.Start);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // @ts-ignore
            TextInput.create({ text: "0.00", placeholder: "请输入金额", controller: this.TextInputController1 });
            TextInput.debugLine("view/Luru.ets(27:9)");
            // @ts-ignore
            TextInput.placeholderColor(Color.Gray);
            // @ts-ignore
            TextInput.placeholderFont({ size: 20, weight: 400 });
            // @ts-ignore
            TextInput.caretColor(Color.Blue);
            // @ts-ignore
            TextInput.width(150);
            // @ts-ignore
            TextInput.height(60);
            // @ts-ignore
            TextInput.margin(20);
            // @ts-ignore
            TextInput.fontSize(30);
            // @ts-ignore
            TextInput.fontColor(Color.Black);
            // @ts-ignore
            TextInput.type(InputType.Normal);
            // @ts-ignore
            TextInput.backgroundColor({ "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            // @ts-ignore
            TextInput.onChange((value) => {
                this.input_money = value;
            });
            if (!isInitialRender) {
                // @ts-ignore
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("view/Luru.ets(43:9)");
            Column.height(60);
            Column.border({ radius: 15 });
            Column.backgroundColor({ "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            Column.width(99);
            Column.onClick(() => {
                DatePickerDialog.show({
                    start: new Date("2000-1-1"),
                    end: new Date(),
                    selected: this.selectedDateInPicker,
                    onAccept: (value) => {
                        // 通过Date的setFullYear方法设置按下确定按钮时的日期，这样当弹窗再次弹出时显示选中的是上一次确定的日期
                        this.selectedDateInPicker.setFullYear(value.year, value.month, value.day);
                        this.selectedDate = this.selectedDateInPicker;
                        this.selectedDateString = this.selectedDateInPicker.toDateString();
                        this.selectedDate_year = this.selectedDateInPicker.getFullYear();
                        this.selectedDate_month = this.selectedDateInPicker.getMonth();
                        this.selectedDate_day = this.selectedDateInPicker.getDate();
                    }
                });
            });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("view/Luru.ets(44:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            Image.debugLine("view/Luru.ets(45:13)");
            Image.objectFit(ImageFit.Auto);
            Image.width(40);
            Image.height(40);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("选择日期");
            Text.debugLine("view/Luru.ets(49:13)");
            Text.fontSize(10);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selectedDateString);
            Text.debugLine("view/Luru.ets(52:11)");
            Text.fontSize(10);
            Text.fontColor({ "id": 16777226, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.create({ placeholder: "请输入备注", controller: this.TextInputController2 });
            TextInput.debugLine("view/Luru.ets(86:7)");
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.placeholderColor(Color.Gray);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.placeholderFont({ size: 15, weight: 400 });
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.caretColor(Color.Blue);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.width(270);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.height(150);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.textAlign(TextAlign.Start);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.margin({ left: 17 });
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.fontSize(15);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.fontColor(Color.Black);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.backgroundColor({ "id": 16777221, "type": 10001, params: [], "bundleName": "com.example.accounthhc", "moduleName": "entry" });
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.maxLength(100);
            // Text("备注:")
            //   .fontSize(15)
            //   .width('100%')
            //   .height(40)
            //   .backgroundColor($r('app.color.gray'))
            //   .margin({left: 0})
            TextInput.onChange((value) => {
                this.beizhu = value;
            });
            if (!isInitialRender) {
                // Text("备注:")
                //   .fontSize(15)
                //   .width('100%')
                //   .height(40)
                //   .backgroundColor($r('app.color.gray'))
                //   .margin({left: 0})
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=Luru.js.map