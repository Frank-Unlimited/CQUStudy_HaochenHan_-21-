/*
由于“首页”和“我的”页面中有多处图片和文字的组合，
* 因此提取出ItemData类。在MainViewModel.et
* s文件中对页面使用的资源进行定义，在MainViewM
* odel.ets文件中定义数据。
 */
export default class PageResource {
    constructor(title, img, imgsrc, others) {
        this.imgsrc = "";
        this.title = title;
        this.img = img;
        this.imgsrc = imgsrc;
        this.others = others;
    }
}
//# sourceMappingURL=ItemData.js.map