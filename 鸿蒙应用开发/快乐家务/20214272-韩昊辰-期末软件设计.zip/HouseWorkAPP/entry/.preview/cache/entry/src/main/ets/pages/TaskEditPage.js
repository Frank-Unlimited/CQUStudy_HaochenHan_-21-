import Prompt from '@ohos:prompt';
import TaskInfoApi from '@bundle:com.example.houseworkapp/entry/ets/database/tables/TaskInfoApi';
import { PersonList } from '@bundle:com.example.houseworkapp/entry/ets/utils/PersonList';
import TaskInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/TaskInfo';
import router from '@ohos:router';
import ReminderItem from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/ReminderItem';
import ReminderService from '@bundle:com.example.houseworkapp/entry/ets/service/ReminderAgent';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
class TaskEditPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = new ObservedPropertyObjectPU(new TaskInfo(0, '', 0, '', false, '', '', '', false, '', true, '', '', '', ''), this, "editTask");
        this.addProvidedVar("editTask", this.__editTask);
        this.isChanged = false;
        this.reminder = new ReminderService();
        this.__personRange = new ObservedPropertyObjectPU([], this, "personRange");
        this.setInitiallyProvidedValue(params);
        this.declareWatch("editTask", this.onTaskChanged);
    }
    setInitiallyProvidedValue(params) {
        if (params.editTask !== undefined) {
            this.editTask = params.editTask;
        }
        if (params.isChanged !== undefined) {
            this.isChanged = params.isChanged;
        }
        if (params.reminder !== undefined) {
            this.reminder = params.reminder;
        }
        if (params.personRange !== undefined) {
            this.personRange = params.personRange;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__personRange.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        this.__personRange.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    get personRange() {
        return this.__personRange.get();
    }
    set personRange(newValue) {
        this.__personRange.set(newValue);
    }
    aboutToAppear() {
        let curDate = new Date();
        this.editTask.date = curDate.toDateString();
        console.log('curDate' + this.editTask.date);
        this.isChanged = false;
        this.setPersonRange();
    }
    onPageShow() {
        this.setPersonRange();
    }
    setPersonRange() {
        this.personRange = ['不限'];
        PersonList.personMap.forEach((val) => {
            this.personRange.push(val.personName);
        });
    }
    onTaskChanged() {
        this.isChanged = true;
    }
    finishTaskEdit(params) {
        console.log(`任务 ${params.date} 时间  ${params.time}`);
        if (this.isChanged) {
            let context = getContext(this);
            if (params.isAlarm) { //开启提醒
                try {
                    let publishReminderInfo = new ReminderItem();
                    publishReminderInfo.hour = Number(params === null || params === void 0 ? void 0 : params.time.split(':')[0]);
                    publishReminderInfo.minute = Number(params === null || params === void 0 ? void 0 : params.time.split(':')[1]);
                    publishReminderInfo.year = Number(params === null || params === void 0 ? void 0 : params.date.split('-')[0]);
                    publishReminderInfo.month = Number(params === null || params === void 0 ? void 0 : params.date.split('-')[1]);
                    publishReminderInfo.day = Number(params === null || params === void 0 ? void 0 : params.date.split('-')[2]);
                    publishReminderInfo.title = params.taskName;
                    publishReminderInfo.content = params.beizhu;
                    publishReminderInfo.notificationId = new Date().getTime();
                    console.log(`提醒年 ${publishReminderInfo.year} 月 ${publishReminderInfo.month} 时分 ${publishReminderInfo.hour} : ${publishReminderInfo.minute} id ${publishReminderInfo.notificationId}`);
                    this.reminder.addReminder(publishReminderInfo, context, (newId) => { params.taskID = newId; Prompt.showToast({ message: '添加提醒成功' }); });
                }
                catch (error) {
                    Logger.error('publishReminder', JSON.stringify(error));
                }
            }
            TaskInfoApi.insertData(params, (flag) => {
                if (flag)
                    console.log('添加任务成功');
            });
            Prompt.showToast({ message: '添加任务成功' });
        }
        router.replaceUrl({
            url: 'pages/Index'
        });
    }
    Menus(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(100:5)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777298, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskEditPage.ets(101:7)");
            Image.width(24);
            Image.onClick(() => {
                this.setPersonRange();
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(110:5)");
            Row.height('100%');
            Row.backgroundColor({ "id": 16777233, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("pages/TaskEditPage.ets(111:7)");
            Navigation.size({ width: '100%', height: '100%' });
            Navigation.title('任务编辑');
            Navigation.titleMode(NavigationTitleMode.Mini);
            Navigation.menus({ builder: () => {
                    this.Menus.call(this);
                } });
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/TaskEditPage.ets(112:9)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 2 });
            List.debugLine("pages/TaskEditPage.ets(113:11)");
            List.width('90%');
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(56);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(114:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditNameItem(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditNameItem(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(56);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(119:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditDate(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditDate(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(56);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(124:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditTime(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditTime(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(56);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(129:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditFlower(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditFlower(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(56);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(134:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditPerson(this, {
                                personRange: this.__personRange
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditPerson(this, {
                                personRange: this.__personRange
                            }, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(30);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(141:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new AddPerson(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new AddPerson(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(56);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(146:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new OpenRemind(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new OpenRemind(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.backgroundColor({ "id": 16777245, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                ListItem.height(240);
                ListItem.borderRadius(10);
                ListItem.padding({ left: 12, right: 12 });
                ListItem.debugLine("pages/TaskEditPage.ets(151:13)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditBeizhu(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new EditBeizhu(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        List.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('完成');
            Button.debugLine("pages/TaskEditPage.ets(158:11)");
            Button.width('80%');
            Button.height(48);
            Button.fontColor(Color.White);
            Button.onClick(() => {
                this.finishTaskEdit(ObservedObject.GetRawObject(this.editTask));
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
        Navigation.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditNameItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(186:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('任务标题');
            Text.debugLine("pages/TaskEditPage.ets(187:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '请输入标题' });
            TextInput.debugLine("pages/TaskEditPage.ets(191:7)");
            TextInput.maxLength(5);
            TextInput.width('50%');
            TextInput.height(50);
            TextInput.fontSize(20);
            TextInput.placeholderFont({ size: 20 });
            TextInput.onChange((val) => {
                this.editTask.taskName = val;
            });
            TextInput.textAlign(TextAlign.End);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditDate extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.selectedDate = new Date();
        this.__selectedDatestr = new ObservedPropertySimplePU('未选择', this, "selectedDatestr");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selectedDate !== undefined) {
            this.selectedDate = params.selectedDate;
        }
        if (params.selectedDatestr !== undefined) {
            this.selectedDatestr = params.selectedDatestr;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedDatestr.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        this.__selectedDatestr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    get selectedDatestr() {
        return this.__selectedDatestr.get();
    }
    set selectedDatestr(newValue) {
        this.__selectedDatestr.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(215:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.onClick(() => {
                DatePickerDialog.show({
                    start: new Date("2000-1-1"),
                    end: new Date("2100-12-31"),
                    selected: this.selectedDate,
                    onAccept: (val) => {
                        this.selectedDate.setFullYear(val.year, val.month, val.day);
                        this.selectedDatestr = `${val.year}-${val.month + 1}-${val.day}`;
                        this.editTask.date = `${val.year}-${val.month + 1}-${val.day}`;
                    }
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('任务完成日期');
            Text.debugLine("pages/TaskEditPage.ets(216:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selectedDatestr);
            Text.debugLine("pages/TaskEditPage.ets(220:7)");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditTime extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.selectTime = new Date('2020-12-25T08:30:00');
        this.__selectTimestr = new ObservedPropertySimplePU('未选择', this, "selectTimestr");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selectTime !== undefined) {
            this.selectTime = params.selectTime;
        }
        if (params.selectTimestr !== undefined) {
            this.selectTimestr = params.selectTimestr;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectTimestr.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        this.__selectTimestr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    get selectTimestr() {
        return this.__selectTimestr.get();
    }
    set selectTimestr(newValue) {
        this.__selectTimestr.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(250:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.onClick(() => {
                TimePickerDialog.show({
                    selected: new Date(this.editTask.date),
                    onAccept: (value) => {
                        this.selectTime.setHours(value.hour, value.minute);
                        this.selectTimestr = this.editTask.time = `${value.hour} : ${value.minute}`;
                    }
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('任务完成时间');
            Text.debugLine("pages/TaskEditPage.ets(251:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selectTimestr);
            Text.debugLine("pages/TaskEditPage.ets(255:7)");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditFlower extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.flowerRange = ['0', '1', '2'];
        this.__selctedFlower = new ObservedPropertySimplePU(0, this, "selctedFlower");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.flowerRange !== undefined) {
            this.flowerRange = params.flowerRange;
        }
        if (params.selctedFlower !== undefined) {
            this.selctedFlower = params.selctedFlower;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selctedFlower.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        this.__selctedFlower.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    get selctedFlower() {
        return this.__selctedFlower.get();
    }
    set selctedFlower(newValue) {
        this.__selctedFlower.set(newValue);
    }
    aboutToAppear() {
        this.flowerRange = [];
        for (let i = 0; i < 100; i++) {
            this.flowerRange.push('' + i);
        }
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(288:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.onClick(() => {
                TextPickerDialog.show({
                    range: this.flowerRange,
                    selected: this.selctedFlower,
                    onAccept: (value) => {
                        this.selctedFlower = parseInt(value.value);
                        this.editTask.targetValue = value.value;
                    }
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('编辑任务奖励');
            Text.debugLine("pages/TaskEditPage.ets(289:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(293:7)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskEditPage.ets(294:9)");
            Image.width(23);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(' x ');
            Text.debugLine("pages/TaskEditPage.ets(296:9)");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selctedFlower + '');
            Text.debugLine("pages/TaskEditPage.ets(300:9)");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditPerson extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.__personRange = new SynchedPropertyObjectTwoWayPU(params.personRange, this, "personRange");
        this.__selctedPerson = new ObservedPropertySimplePU('不限', this, "selctedPerson");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selctedPerson !== undefined) {
            this.selctedPerson = params.selctedPerson;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__personRange.purgeDependencyOnElmtId(rmElmtId);
        this.__selctedPerson.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        this.__personRange.aboutToBeDeleted();
        this.__selctedPerson.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    get personRange() {
        return this.__personRange.get();
    }
    set personRange(newValue) {
        this.__personRange.set(newValue);
    }
    get selctedPerson() {
        return this.__selctedPerson.get();
    }
    set selctedPerson(newValue) {
        this.__selctedPerson.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(329:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.onClick(() => {
                TextPickerDialog.show({
                    range: this.personRange,
                    onAccept: (value) => {
                        this.selctedPerson = value.value;
                        this.editTask.personName = value.value;
                    }
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('指定完成任务的家庭成员');
            Text.debugLine("pages/TaskEditPage.ets(330:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selctedPerson);
            Text.debugLine("pages/TaskEditPage.ets(334:7)");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class AddPerson extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(357:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.Start);
            Row.onClick(() => {
                router.pushUrl({
                    url: 'pages/PersonEdit'
                });
            });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('编辑家庭成员');
            Text.debugLine("pages/TaskEditPage.ets(358:7)");
            Text.fontSize(15);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Blue);
            Text.decoration({ type: TextDecorationType.Underline, color: Color.Blue });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class OpenRemind extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEditPage.ets(378:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('开启提醒');
            Text.debugLine("pages/TaskEditPage.ets(379:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Toggle.create({ type: ToggleType.Switch, isOn: this.editTask.isAlarm });
            Toggle.debugLine("pages/TaskEditPage.ets(383:7)");
            Toggle.width(56);
            Toggle.height(32);
            Toggle.selectedColor({ "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Toggle.onChange((isOn) => {
                this.editTask.isAlarm = isOn;
            });
            if (!isInitialRender) {
                Toggle.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Toggle.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditBeizhu extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 2 });
            Column.debugLine("pages/TaskEditPage.ets(401:5)");
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Start);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('添加备注');
            Text.debugLine("pages/TaskEditPage.ets(402:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '添加备注 (50字以内)' });
            TextInput.debugLine("pages/TaskEditPage.ets(406:7)");
            TextInput.placeholderFont({ size: 15 });
            TextInput.fontSize(15);
            TextInput.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            TextInput.maxLength(50);
            TextInput.width('100%');
            TextInput.height(200);
            TextInput.onChange((val) => {
                this.editTask.beizhu = val;
            });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(2, "TaskEditPage", new TaskEditPage(undefined, {}), "EditNameItem", new EditNameItem(undefined, {}));
    ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
    loadDocument(new TaskEditPage(undefined, {}));
    ViewStackProcessor.StopGetAccessRecording();
}
//# sourceMappingURL=TaskEditPage.js.map