/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import window from '@ohos:window';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
import DrawModel from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/DrawModel';
import PrizeDialog from '@bundle:com.example.houseworkapp/entry/ets/view/PrizeDialog';
import PrizeData from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/PrizeData';
import StyleConstants from '@bundle:com.example.houseworkapp/entry/ets/constants/StyleConstants';
import { CommonConstants } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
import { PersonList } from '@bundle:com.example.houseworkapp/entry/ets/utils/PersonList';
import PersonInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/PersonInfo';
import Prompt from '@ohos:prompt';
import PersonInfoApi from '@bundle:com.example.houseworkapp/entry/ets/database/tables/PersonInfoApi';
// Get context.
let context = getContext(this);
class CanvasPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.settings = new RenderingContextSettings(true);
        this.canvasContext = new CanvasRenderingContext2D(this.settings);
        this.__drawModel = new ObservedPropertyObjectPU(new DrawModel(), this, "drawModel");
        this.__screenWidth = new ObservedPropertySimplePU(0, this, "screenWidth");
        this.__screenHeight = new ObservedPropertySimplePU(0, this, "screenHeight");
        this.__rotateDegree = new ObservedPropertySimplePU(0, this, "rotateDegree");
        this.__enableFlag = new ObservedPropertySimplePU(true, this, "enableFlag");
        this.__prizeData = new ObservedPropertyObjectPU(new PrizeData(), this, "prizeData");
        this.personNameRange = [];
        this.__selectedPersonName = new ObservedPropertySimplePU('请选择抽奖人', this, "selectedPersonName");
        this.__person = new ObservedPropertyObjectPU(new PersonInfo('NULL', 'NULL', 0), this, "person");
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new PrizeDialog(this, {
                    prizeData: this.__prizeData,
                    enableFlag: this.__enableFlag
                });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
            },
            autoCancel: false
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.canvasContext !== undefined) {
            this.canvasContext = params.canvasContext;
        }
        if (params.drawModel !== undefined) {
            this.drawModel = params.drawModel;
        }
        if (params.screenWidth !== undefined) {
            this.screenWidth = params.screenWidth;
        }
        if (params.screenHeight !== undefined) {
            this.screenHeight = params.screenHeight;
        }
        if (params.rotateDegree !== undefined) {
            this.rotateDegree = params.rotateDegree;
        }
        if (params.enableFlag !== undefined) {
            this.enableFlag = params.enableFlag;
        }
        if (params.prizeData !== undefined) {
            this.prizeData = params.prizeData;
        }
        if (params.personNameRange !== undefined) {
            this.personNameRange = params.personNameRange;
        }
        if (params.selectedPersonName !== undefined) {
            this.selectedPersonName = params.selectedPersonName;
        }
        if (params.person !== undefined) {
            this.person = params.person;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__drawModel.purgeDependencyOnElmtId(rmElmtId);
        this.__screenWidth.purgeDependencyOnElmtId(rmElmtId);
        this.__screenHeight.purgeDependencyOnElmtId(rmElmtId);
        this.__rotateDegree.purgeDependencyOnElmtId(rmElmtId);
        this.__enableFlag.purgeDependencyOnElmtId(rmElmtId);
        this.__prizeData.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedPersonName.purgeDependencyOnElmtId(rmElmtId);
        this.__person.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__drawModel.aboutToBeDeleted();
        this.__screenWidth.aboutToBeDeleted();
        this.__screenHeight.aboutToBeDeleted();
        this.__rotateDegree.aboutToBeDeleted();
        this.__enableFlag.aboutToBeDeleted();
        this.__prizeData.aboutToBeDeleted();
        this.__selectedPersonName.aboutToBeDeleted();
        this.__person.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get drawModel() {
        return this.__drawModel.get();
    }
    set drawModel(newValue) {
        this.__drawModel.set(newValue);
    }
    get screenWidth() {
        return this.__screenWidth.get();
    }
    set screenWidth(newValue) {
        this.__screenWidth.set(newValue);
    }
    get screenHeight() {
        return this.__screenHeight.get();
    }
    set screenHeight(newValue) {
        this.__screenHeight.set(newValue);
    }
    get rotateDegree() {
        return this.__rotateDegree.get();
    }
    set rotateDegree(newValue) {
        this.__rotateDegree.set(newValue);
    }
    get enableFlag() {
        return this.__enableFlag.get();
    }
    set enableFlag(newValue) {
        this.__enableFlag.set(newValue);
    }
    get prizeData() {
        return this.__prizeData.get();
    }
    set prizeData(newValue) {
        this.__prizeData.set(newValue);
    }
    get selectedPersonName() {
        return this.__selectedPersonName.get();
    }
    set selectedPersonName(newValue) {
        this.__selectedPersonName.set(newValue);
    }
    get person() {
        return this.__person.get();
    }
    set person(newValue) {
        this.__person.set(newValue);
    }
    aboutToAppear() {
        // Obtains the width and height of the screen, excluding the height of the navigation view.
        window.getLastWindow(context)
            .then((windowClass) => {
            let windowProperties = windowClass.getWindowProperties();
            this.screenWidth = px2vp(windowProperties.windowRect.width);
            this.screenHeight = px2vp(windowProperties.windowRect.height);
        })
            .catch((error) => {
            Logger.error('Failed to obtain the window size. Cause: ' + JSON.stringify(error));
        });
        for (let val of PersonList.personMap.values()) {
            this.personNameRange.push(val.personName);
        }
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create({ alignContent: Alignment.Center });
            Stack.debugLine("pages/CanvasPage.ets(70:5)");
            Stack.width(StyleConstants.FULL_PERCENT);
            Stack.height(StyleConstants.FULL_PERCENT);
            Stack.backgroundImage({ "id": 16777285, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" }, ImageRepeat.NoRepeat);
            Stack.backgroundImageSize({
                width: StyleConstants.FULL_PERCENT,
                height: StyleConstants.BACKGROUND_IMAGE_SIZE
            });
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/CanvasPage.ets(71:7)");
            Column.zIndex(2);
            Column.width('80%');
            Column.height('30%');
            Column.position({ x: '5%', y: '10%' });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 2 });
            Row.debugLine("pages/CanvasPage.ets(72:9)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selectedPersonName);
            Text.debugLine("pages/CanvasPage.ets(73:11)");
            Text.fontSize(20);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Text.width('50%');
            Text.onClick(() => {
                Prompt.showToast({ message: '选择抽奖人' });
                TextPickerDialog.show({
                    range: this.personNameRange,
                    onAccept: (val) => {
                        this.selectedPersonName = val.value;
                        this.person = PersonList.queryByName(this.selectedPersonName);
                    }
                });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 2 });
            Row.debugLine("pages/CanvasPage.ets(88:11)");
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('剩余鲜花数:');
            Text.debugLine("pages/CanvasPage.ets(89:13)");
            Text.fontSize(16);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/CanvasPage.ets(93:13)");
            Image.width(20);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(' x ' + this.person.personValue);
            Text.debugLine("pages/CanvasPage.ets(96:13)");
            Text.fontSize(16);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('每次抽奖将消耗5个鲜花！');
            Text.debugLine("pages/CanvasPage.ets(110:7)");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            Text.position({ x: '7%', y: '90%' });
            Text.alignSelf(ItemAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Canvas.create(this.canvasContext);
            Canvas.debugLine("pages/CanvasPage.ets(116:7)");
            Canvas.width(StyleConstants.FULL_PERCENT);
            Canvas.height(StyleConstants.FULL_PERCENT);
            Canvas.onReady(() => {
                this.drawModel.draw(this.canvasContext, this.screenWidth, this.screenHeight);
            });
            Canvas.rotate({
                x: 0,
                y: 0,
                z: 1,
                angle: this.rotateDegree,
                centerX: this.screenWidth / CommonConstants.TWO,
                centerY: this.screenHeight / CommonConstants.TWO
            });
            Canvas.zIndex(0);
            if (!isInitialRender) {
                Canvas.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Canvas.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777274, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/CanvasPage.ets(132:7)");
            Image.width(StyleConstants.CENTER_IMAGE_WIDTH);
            Image.height(StyleConstants.CENTER_IMAGE_HEIGHT);
            Image.enabled(this.enableFlag);
            Image.onClick(() => {
                if (this.person.personValue < 5) {
                    Prompt.showToast({ message: '余额不足,再去做点家务吧' });
                }
                else {
                    this.enableFlag = !this.enableFlag;
                    this.startAnimator();
                    this.person.personValue -= 5;
                    PersonInfoApi.updateDataByName(ObservedObject.GetRawObject(this.person), () => { });
                    PersonList.updatePerson(ObservedObject.GetRawObject(this.person));
                }
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Stack.pop();
    }
    /**
     * Start animator.
     */
    startAnimator() {
        let randomAngle = Math.round(Math.random() * CommonConstants.CIRCLE);
        // Obtaining prize information.
        this.prizeData = this.drawModel.showPrizeData(randomAngle);
        Context.animateTo({
            duration: CommonConstants.DURATION,
            curve: Curve.Ease,
            delay: 0,
            iterations: 1,
            playMode: PlayMode.Normal,
            onFinish: () => {
                this.rotateDegree = CommonConstants.ANGLE - randomAngle;
                // Display prize information pop-up window.
                this.dialogController.open();
            }
        }, () => {
            this.rotateDegree = CommonConstants.CIRCLE * CommonConstants.FIVE +
                CommonConstants.ANGLE - randomAngle;
        });
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new CanvasPage(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=CanvasPage.js.map