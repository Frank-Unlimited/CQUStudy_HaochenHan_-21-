/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import dataRdb from '@ohos:data.relationalStore';
import PersonInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/PersonInfo';
import { CommonConstants as Const } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
import RdbUtils from '@bundle:com.example.houseworkapp/entry/ets/database/rdb/RdbUtils';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
class PersonInfoApi {
    /**
     * insert taskInfo
     *
     * @param taskInfo
     * @param callback
     */
    insertData(personInfo, callback) {
        const valueBucket = generateBucket(personInfo);
        RdbUtils.insert('personInfo', valueBucket).then(result => {
            callback(result);
        });
        Logger.info('PersonInfo', `Insert PersonInfo {${personInfo.personName}:${personInfo.personValue}} finished.`);
    }
    /**
     * delete taskInfo
     *
     * @param taskInfo
     * @param callback
     */
    deleteDataByName(personName, callback) {
        let tableName = Const.Person_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('personName', personName);
        RdbUtils.del(predicates).then(result => {
            callback(result);
        });
        Logger.info('personInfo', `Delete personInfo {${personName} finished.`);
    }
    /**
     * update taskInfo
     *
     * @param taskInfo
     * @param callback
     */
    updateDataByName(personInfo, callback) {
        const valueBucket = generateBucket(personInfo);
        let tableName = Const.Person_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('personName', personInfo.personName).and().equalTo('personStatus', personInfo.personStatus);
        RdbUtils.update(valueBucket, predicates).then((result) => {
            callback(result);
        });
        Logger.info('PersonInfoTable', `Update data {${JSON.stringify(personInfo)} finished.`);
    }
    query(personName, callback) {
        let tableName = Const.Person_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('personName', personName);
        RdbUtils.query(predicates).then(resultSet => {
            let count = resultSet.rowCount;
            if (count === 0 || typeof count === 'string') {
                let result = new PersonInfo();
                callback(result);
            }
            else {
                resultSet.goToFirstRow();
                let result = new PersonInfo();
                result.personName = resultSet.getString(resultSet.getColumnIndex('personName'));
                result.personStatus = resultSet.getString(resultSet.getColumnIndex('personStatus'));
                result.personValue = resultSet.getDouble(resultSet.getColumnIndex('personValue'));
                callback(result);
            }
        });
    }
    query_all(callback) {
        console.log('query_all goin');
        let tableName = Const.Person_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.notEqualTo('personName', 'laozi');
        RdbUtils.query(predicates).then(resultSet => {
            let count = resultSet.rowCount;
            console.log('查询到数据量：' + count);
            if (count === 0 || typeof count === 'string') {
                let result = [];
                callback(result);
            }
            else {
                resultSet.goToFirstRow();
                let result = [];
                for (let i = 0; i < count; i++) {
                    let tmp = new PersonInfo();
                    tmp.personName = resultSet.getString(resultSet.getColumnIndex('personName'));
                    tmp.personStatus = resultSet.getString(resultSet.getColumnIndex('personStatus'));
                    tmp.personValue = resultSet.getDouble(resultSet.getColumnIndex('personValue'));
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);
            }
        });
    }
}
function generateBucket(personInfo) {
    var _a;
    let valueBucket = {};
    (_a = Const.Person_INFO.columns) === null || _a === void 0 ? void 0 : _a.forEach((item) => {
        if (item !== 'id') {
            switch (item) {
                case 'personName':
                    valueBucket[item] = personInfo.personName;
                    break;
                case 'personValue':
                    valueBucket[item] = personInfo.personValue;
                    break;
                case 'personStatus':
                    valueBucket[item] = personInfo.personStatus;
                    break;
                default:
                    break;
            }
        }
    });
    return valueBucket;
}
let personInfoApi = new PersonInfoApi();
export default personInfoApi;
//# sourceMappingURL=PersonInfoApi.js.map