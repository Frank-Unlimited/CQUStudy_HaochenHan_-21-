/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import reminderAgent from '@ohos:reminderAgentManager';
import notification from '@ohos:notificationManager';
import preferences from '@ohos:data.preferences';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
import { CommonConstants as Const } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
export default class ReminderService {
    hasPreferencesValue(context, hasKey, callback) {
        let preferencesPromise = preferences.getPreferences(context, Const.H_STORE);
        preferencesPromise.then((preferences) => {
            preferences.has(hasKey).then((hasValue) => {
                callback(preferences, hasValue);
            });
        });
    }
    processReminderData(params, preferences, notifyId) {
        let timer = this.initReminder(params);
        reminderAgent.publishReminder(timer).then((reminderId) => {
            this.putPreferencesValue(preferences, notifyId, reminderId);
        }).catch((err) => {
            Logger.error(Const.REMINDER_AGENT_TAG, `publishReminder err: ${err}`);
        });
    }
    putPreferencesValue(preferences, putKey, putValue) {
        preferences.put(putKey, putValue).then(() => {
            preferences.flush();
        }).catch((error) => {
            Logger.error(Const.REMINDER_AGENT_TAG, 'preferences put value error ' + JSON.stringify(error));
        });
    }
    addReminder(alarmItem, context, callback) {
        let notifyId = alarmItem.notificationId.toString();
        this.hasPreferencesValue(context, notifyId, (preferences, hasValue) => {
            if (hasValue) {
                preferences.get(notifyId, -1, (error, value) => {
                    if (typeof value !== 'number') {
                        return;
                    }
                    if (value >= 0) {
                        reminderAgent.cancelReminder(value).then(() => {
                            this.processReminderData(alarmItem, preferences, notifyId);
                        }).catch((err) => {
                            Logger.error(Const.REMINDER_AGENT_TAG, `cancelReminder err: ${err}`);
                        });
                    }
                    else {
                        Logger.error(Const.REMINDER_AGENT_TAG, 'preferences get value error ' + JSON.stringify(error));
                    }
                });
            }
            else {
                this.processReminderData(alarmItem, preferences, notifyId);
            }
        });
    }
    initReminder(item) {
        return {
            reminderType: reminderAgent.ReminderType.REMINDER_TYPE_CALENDAR,
            dateTime: {
                year: item.year,
                month: item.month,
                day: item.day,
                hour: item.hour,
                minute: item.minute,
                second: 0
            },
            title: item.title,
            content: item.content,
            notificationId: item.notificationId || -1,
            wantAgent: {
                pkgName: 'com.example.houseworkapp',
                abilityName: 'EntryAbility'
            },
            slotType: notification.SlotType.SOCIAL_COMMUNICATION,
        };
    }
    deleteReminder(reminderId) {
        reminderAgent.cancelReminder(reminderId);
    }
}
//# sourceMappingURL=ReminderAgent.js.map