import Prompt from '@ohos:prompt';
import PersonInfoApi from '@bundle:com.example.houseworkapp/entry/ets/database/tables/PersonInfoApi';
import { PersonList } from '@bundle:com.example.houseworkapp/entry/ets/utils/PersonList';
import PersonInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/PersonInfo';
class AddPersonDialog extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.controller = undefined;
        this.person = new PersonInfo();
        this.statusRange = ['儿子', '女儿', '父亲', '母亲', '爷爷', '奶奶', '保姆', '来客', '其他'];
        this.__selectedStatus = new ObservedPropertySimplePU('未选择', this, "selectedStatus");
        this.__arr = this.initializeConsume("arr", "arr");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.person !== undefined) {
            this.person = params.person;
        }
        if (params.statusRange !== undefined) {
            this.statusRange = params.statusRange;
        }
        if (params.selectedStatus !== undefined) {
            this.selectedStatus = params.selectedStatus;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedStatus.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedStatus.aboutToBeDeleted();
        this.__arr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    setController(ctr) {
        this.controller = ctr;
    }
    get selectedStatus() {
        return this.__selectedStatus.get();
    }
    set selectedStatus(newValue) {
        this.__selectedStatus.set(newValue);
    }
    get arr() {
        return this.__arr.get();
    }
    set arr(newValue) {
        this.__arr.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 20 });
            Column.debugLine("pages/PersonEdit.ets(21:5)");
            Column.height('30%');
            Column.width('90%');
            Column.padding(10);
            Column.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PersonEdit.ets(22:7)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('姓名');
            Text.debugLine("pages/PersonEdit.ets(23:9)");
            Text.width('20%');
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '请输入姓名' });
            TextInput.debugLine("pages/PersonEdit.ets(26:9)");
            TextInput.width('40%');
            TextInput.onChange((val) => { this.person.personName = val; });
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/PersonEdit.ets(33:7)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('身份');
            Text.debugLine("pages/PersonEdit.ets(34:9)");
            Text.width('20%');
            Text.fontSize(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.selectedStatus);
            Text.debugLine("pages/PersonEdit.ets(37:9)");
            Text.fontSize(15);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Text.onClick(() => {
                TextPickerDialog.show({
                    range: this.statusRange,
                    onAccept: (val) => {
                        this.selectedStatus = val.value;
                        this.person.personStatus = val.value;
                    }
                });
            });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('鲜花初始化为0！');
            Text.debugLine("pages/PersonEdit.ets(53:7)");
            Text.fontSize(20);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('确定');
            Button.debugLine("pages/PersonEdit.ets(57:7)");
            Button.width('60%');
            Button.fontWeight(FontWeight.Bold);
            Button.fontColor(Color.White);
            Button.onClick(() => {
                this.person.personValue = 0;
                PersonInfoApi.insertData(this.person, (flag) => {
                    if (flag) {
                        Prompt.showToast({ message: '插入成功' });
                    }
                    else {
                        Prompt.showToast({ message: '插入失败' });
                    }
                });
                PersonList.addPerson(this.person);
                this.arr.push(this.person);
                Prompt.showToast({ message: '插入成功' });
                this.controller.close();
            });
            Button.alignSelf(ItemAlign.Center);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class PersonEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__arr = new ObservedPropertyObjectPU([], this, "arr");
        this.addProvidedVar("arr", this.__arr);
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new AddPersonDialog(this, {});
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
            }
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.arr !== undefined) {
            this.arr = params.arr;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__arr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get arr() {
        return this.__arr.get();
    }
    set arr(newValue) {
        this.__arr.set(newValue);
    }
    aboutToAppear() {
        console.log('forEach aboutToAppear');
        PersonList.personMap.forEach((value) => {
            this.arr.push(value);
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("pages/PersonEdit.ets(100:5)");
            Navigation.titleMode(NavigationTitleMode.Mini);
            Navigation.title('家庭成员信息');
            Navigation.size({ width: '100%', height: '100%' });
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/PersonEdit.ets(101:7)");
            Column.width('90%');
            Column.height('100%');
            Column.backgroundColor({ "id": 16777233, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Column.padding({ top: 5 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel('添加家庭成员');
            Button.debugLine("pages/PersonEdit.ets(102:9)");
            Button.width('70%');
            Button.fontColor(Color.White);
            Button.fontWeight(FontWeight.Bold);
            Button.onClick(() => {
                this.dialogController.open();
            });
            Button.margin(10);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 20, initialIndex: 0 });
            List.debugLine("pages/PersonEdit.ets(111:9)");
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            const isLazyCreate = true;
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, isLazyCreate);
                ListItem.debugLine("pages/PersonEdit.ets(112:11)");
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const observedShallowRender = () => {
                this.observeComponentCreation(itemCreation);
                ListItem.pop();
            };
            const observedDeepRender = () => {
                this.observeComponentCreation(itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/PersonEdit.ets(113:15)");
                    Row.width('100%');
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('姓名');
                    Text.debugLine("pages/PersonEdit.ets(114:17)");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('40%');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('身份');
                    Text.debugLine("pages/PersonEdit.ets(119:17)");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('40%');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create({ space: 5 });
                    Row.debugLine("pages/PersonEdit.ets(125:17)");
                    Row.width('20%');
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('鲜花');
                    Text.debugLine("pages/PersonEdit.ets(126:19)");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                    Image.debugLine("pages/PersonEdit.ets(130:19)");
                    Image.width(20);
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Row.pop();
                Row.pop();
                ListItem.pop();
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.updateFuncByElmtId.set(elmtId, itemCreation);
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create();
                    Row.debugLine("pages/PersonEdit.ets(113:15)");
                    Row.width('100%');
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('姓名');
                    Text.debugLine("pages/PersonEdit.ets(114:17)");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('40%');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('身份');
                    Text.debugLine("pages/PersonEdit.ets(119:17)");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    Text.width('40%');
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Row.create({ space: 5 });
                    Row.debugLine("pages/PersonEdit.ets(125:17)");
                    Row.width('20%');
                    if (!isInitialRender) {
                        Row.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create('鲜花');
                    Text.debugLine("pages/PersonEdit.ets(126:19)");
                    Text.fontSize(20);
                    Text.fontWeight(FontWeight.Bold);
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create({ "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                    Image.debugLine("pages/PersonEdit.ets(130:19)");
                    Image.width(20);
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Row.pop();
                Row.pop();
                ListItem.pop();
            };
            if (isLazyCreate) {
                observedShallowRender();
            }
            else {
                observedDeepRender();
            }
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/PersonEdit.ets(138:13)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/PersonEdit.ets(139:15)");
                            Row.width('100%');
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.personName);
                            Text.debugLine("pages/PersonEdit.ets(140:17)");
                            Text.fontSize(20);
                            Text.width('40%');
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.personStatus);
                            Text.debugLine("pages/PersonEdit.ets(144:17)");
                            Text.fontSize(20);
                            Text.width('40%');
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.personValue + '');
                            Text.debugLine("pages/PersonEdit.ets(148:17)");
                            Text.fontSize(20);
                            Text.width('20%');
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Row.create();
                            Row.debugLine("pages/PersonEdit.ets(139:15)");
                            Row.width('100%');
                            if (!isInitialRender) {
                                Row.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.personName);
                            Text.debugLine("pages/PersonEdit.ets(140:17)");
                            Text.fontSize(20);
                            Text.width('40%');
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.personStatus);
                            Text.debugLine("pages/PersonEdit.ets(144:17)");
                            Text.fontSize(20);
                            Text.width('40%');
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item.personValue + '');
                            Text.debugLine("pages/PersonEdit.ets(148:17)");
                            Text.fontSize(20);
                            Text.width('20%');
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.arr, forEachItemGenFunction, (item) => item.personName, false, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Column.pop();
        Navigation.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new PersonEdit(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=PersonEdit.js.map