export default class ReminderItem {
    constructor() {
        this.hour = 0;
        this.minute = 0;
        this.year = 2023;
        this.month = 1;
        this.day = 1;
        this.title = '';
        this.content = '';
        this.notificationId = 0;
    }
}
//# sourceMappingURL=ReminderItem.js.map