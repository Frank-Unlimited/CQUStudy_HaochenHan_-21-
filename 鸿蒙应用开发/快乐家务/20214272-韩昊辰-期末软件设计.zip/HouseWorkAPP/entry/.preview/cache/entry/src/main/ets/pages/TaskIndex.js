import router from '@ohos:router';
import Prompt from '@ohos:prompt';
import TaskInfoApi from '@bundle:com.example.houseworkapp/entry/ets/database/tables/TaskInfoApi';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
import { PersonList } from '@bundle:com.example.houseworkapp/entry/ets/utils/PersonList';
import ReminderItem from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/ReminderItem';
import ReminderService from '@bundle:com.example.houseworkapp/entry/ets/service/ReminderAgent';
import PersonInfoApi from '@bundle:com.example.houseworkapp/entry/ets/database/tables/PersonInfoApi';
export class TaskIndex extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__selectedDateStr = new ObservedPropertySimplePU('2023-12-12', this, "selectedDateStr");
        this.selectedDate = new Date();
        this.__selectedPersonStr = new ObservedPropertySimplePU('不限', this, "selectedPersonStr");
        this.personNameRange = ['不限'];
        this.__taskList = new ObservedPropertyObjectPU([], this, "taskList");
        this.addProvidedVar("taskList", this.__taskList);
        this.__isDone = new ObservedPropertySimplePU(false, this, "isDone");
        this.__isShengxu = new ObservedPropertySimplePU(false, this, "isShengxu");
        this.__sortWay = new ObservedPropertySimplePU(0 //0: 按照时间 1：按照鲜花 2：只看未完成 3：只看已完成
        , this, "sortWay");
        this.__isSearch = new ObservedPropertySimplePU(false, this, "isSearch");
        this.__textInputWidth = new ObservedPropertySimplePU(0, this, "textInputWidth");
        this.searchText = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.selectedDateStr !== undefined) {
            this.selectedDateStr = params.selectedDateStr;
        }
        if (params.selectedDate !== undefined) {
            this.selectedDate = params.selectedDate;
        }
        if (params.selectedPersonStr !== undefined) {
            this.selectedPersonStr = params.selectedPersonStr;
        }
        if (params.personNameRange !== undefined) {
            this.personNameRange = params.personNameRange;
        }
        if (params.taskList !== undefined) {
            this.taskList = params.taskList;
        }
        if (params.isDone !== undefined) {
            this.isDone = params.isDone;
        }
        if (params.isShengxu !== undefined) {
            this.isShengxu = params.isShengxu;
        }
        if (params.sortWay !== undefined) {
            this.sortWay = params.sortWay;
        }
        if (params.isSearch !== undefined) {
            this.isSearch = params.isSearch;
        }
        if (params.textInputWidth !== undefined) {
            this.textInputWidth = params.textInputWidth;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedDateStr.purgeDependencyOnElmtId(rmElmtId);
        this.__selectedPersonStr.purgeDependencyOnElmtId(rmElmtId);
        this.__isDone.purgeDependencyOnElmtId(rmElmtId);
        this.__isShengxu.purgeDependencyOnElmtId(rmElmtId);
        this.__sortWay.purgeDependencyOnElmtId(rmElmtId);
        this.__isSearch.purgeDependencyOnElmtId(rmElmtId);
        this.__textInputWidth.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedDateStr.aboutToBeDeleted();
        this.__selectedPersonStr.aboutToBeDeleted();
        this.__taskList.aboutToBeDeleted();
        this.__isDone.aboutToBeDeleted();
        this.__isShengxu.aboutToBeDeleted();
        this.__sortWay.aboutToBeDeleted();
        this.__isSearch.aboutToBeDeleted();
        this.__textInputWidth.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get selectedDateStr() {
        return this.__selectedDateStr.get();
    }
    set selectedDateStr(newValue) {
        this.__selectedDateStr.set(newValue);
    }
    get selectedPersonStr() {
        return this.__selectedPersonStr.get();
    }
    set selectedPersonStr(newValue) {
        this.__selectedPersonStr.set(newValue);
    }
    get taskList() {
        return this.__taskList.get();
    }
    set taskList(newValue) {
        this.__taskList.set(newValue);
    }
    get isDone() {
        return this.__isDone.get();
    }
    set isDone(newValue) {
        this.__isDone.set(newValue);
    }
    get isShengxu() {
        return this.__isShengxu.get();
    }
    set isShengxu(newValue) {
        this.__isShengxu.set(newValue);
    }
    get sortWay() {
        return this.__sortWay.get();
    }
    set sortWay(newValue) {
        this.__sortWay.set(newValue);
    }
    get isSearch() {
        return this.__isSearch.get();
    }
    set isSearch(newValue) {
        this.__isSearch.set(newValue);
    }
    get textInputWidth() {
        return this.__textInputWidth.get();
    }
    set textInputWidth(newValue) {
        this.__textInputWidth.set(newValue);
    }
    onselectedDateChanged() {
        this.selectedDateStr = `${this.selectedDate.getFullYear()}-${this.selectedDate.getMonth() + 1}-${this.selectedDate.getDate()}`;
    }
    onPageShow() {
        console.log('TaskIndex onPageShow');
        this.selectedDateStr = `${this.selectedDate.getFullYear()}-${this.selectedDate.getMonth() + 1}-${this.selectedDate.getDate()}`;
        this.personNameRange = ['不限'];
        PersonList.personMap.forEach((val) => {
            this.personNameRange.push(val.personName);
        });
        this.isDone = null;
        this.updateTaskLis_date();
    }
    aboutToAppear() {
        console.log('TaskIndex onPageShow');
        this.selectedDateStr = `${this.selectedDate.getFullYear()}-${this.selectedDate.getMonth() + 1}-${this.selectedDate.getDate()}`;
        this.personNameRange = ['不限'];
        PersonList.personMap.forEach((val) => {
            this.personNameRange.push(val.personName);
        });
        this.isDone = null;
        this.updateTaskLis_date();
    }
    updateTaskLis_date() {
        //  @State sortWay: number = 0  //0: 按照时间 1：按照鲜花 2：只看未完成 3：只看已完成
        if (this.sortWay == 0) {
            TaskInfoApi.query_date(this.selectedDateStr, (res) => { this.taskList = res; console.log('update taskList length:' + res.length); }, this.selectedPersonStr, null, 'time');
        }
        else if (this.sortWay == 1) {
            TaskInfoApi.query_date(this.selectedDateStr, (res) => { this.taskList = res; console.log('update taskList length:' + res.length); }, this.selectedPersonStr, null, 'targetValue');
        }
        else if (this.sortWay == 2) {
            TaskInfoApi.query_date(this.selectedDateStr, (res) => { this.taskList = res; console.log('update taskList length:' + res.length); }, this.selectedPersonStr, false);
        }
        else {
            TaskInfoApi.query_date(this.selectedDateStr, (res) => { this.taskList = res; console.log('update taskList length:' + res.length); }, this.selectedPersonStr, true);
        }
    }
    updateTaskLis_search() {
        TaskInfoApi.query_search(this.searchText, (res) => { this.taskList = res; console.log('update taskList length:' + res.length); Prompt.showToast({ message: '查询成功' }); });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/TaskIndex.ets(81:5)");
            Stack.width('100%');
            Stack.height('100%');
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777266, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(82:7)");
            Image.width(70);
            Image.position({ x: 270, y: 700 });
            Image.zIndex(2);
            Image.onClick(() => {
                router.pushUrl({
                    url: 'pages/TaskEditPage'
                });
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 10 });
            Column.debugLine("pages/TaskIndex.ets(92:7)");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Start);
            Column.zIndex(0);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777263, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(93:9)");
            Image.width('90%');
            Image.objectFit(ImageFit.Contain);
            Image.margin({ top: '5%', bottom: 10 });
            Image.border({ radius: 20 });
            Image.shadow({ radius: 40 });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 5 });
            Row.debugLine("pages/TaskIndex.ets(101:9)");
            Row.width('90%');
            Row.height(30);
            Row.border({ radius: 20 });
            Row.justifyContent(FlexAlign.SpaceEvenly);
            Row.backgroundColor({ "id": 16777246, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Row.shadow({ radius: 10, color: Color.Gray });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.isSearch == false) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create({ space: 5 });
                        Row.debugLine("pages/TaskIndex.ets(103:13)");
                        Row.onClick(() => {
                            DatePickerDialog.show({
                                selected: this.selectedDate,
                                onAccept: (val) => {
                                    this.selectedDate.setFullYear(val.year, val.month, val.day);
                                    this.onselectedDateChanged();
                                    this.updateTaskLis_date();
                                }
                            });
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777297, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        Image.debugLine("pages/TaskIndex.ets(104:15)");
                        Image.width(24);
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(this.selectedDateStr);
                        Text.debugLine("pages/TaskIndex.ets(107:15)");
                        Text.fontSize(12);
                        Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create({ space: 5 });
                        Row.debugLine("pages/TaskIndex.ets(122:13)");
                        Row.onClick(() => {
                            TextPickerDialog.show({
                                range: this.personNameRange,
                                selected: 0,
                                onAccept: (val) => {
                                    this.selectedPersonStr = val.value;
                                    this.updateTaskLis_date();
                                }
                            });
                        });
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777280, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        Image.debugLine("pages/TaskIndex.ets(123:15)");
                        Image.width(24);
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(this.selectedPersonStr);
                        Text.debugLine("pages/TaskIndex.ets(126:15)");
                        Text.fontSize(12);
                        Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    Row.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777272, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        Image.debugLine("pages/TaskIndex.ets(141:13)");
                        Image.width(24);
                        Image.onClick(() => {
                            TextPickerDialog.show({
                                range: ['按时间排序', '按鲜花排序', '只看未完成', '只看已完成'],
                                selected: this.sortWay,
                                onAccept: (val) => {
                                    this.sortWay = val.index;
                                    this.updateTaskLis_date();
                                }
                            });
                        });
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        If.create();
                        if (this.isShengxu) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation((elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    Image.create({ "id": 16777270, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                                    Image.debugLine("pages/TaskIndex.ets(155:15)");
                                    Image.width(24);
                                    Image.onClick(() => {
                                        this.isShengxu = !this.isShengxu;
                                        this.taskList.reverse();
                                    });
                                    if (!isInitialRender) {
                                        Image.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                });
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation((elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    Image.create({ "id": 16777277, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                                    Image.debugLine("pages/TaskIndex.ets(163:15)");
                                    Image.width(24);
                                    Image.onClick(() => {
                                        this.isShengxu = !this.isShengxu;
                                        this.taskList.reverse();
                                    });
                                    if (!isInitialRender) {
                                        Image.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                });
                            });
                        }
                        if (!isInitialRender) {
                            If.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    If.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777284, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(173:11)");
            Image.width(24);
            Image.onClick(() => {
                this.isSearch = !this.isSearch;
                this.textInputWidth = 0;
                this.updateTaskLis_date();
            });
            Image.visibility(this.isSearch ? Visibility.Visible : Visibility.None);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: '输入家务关键词' });
            TextInput.debugLine("pages/TaskIndex.ets(182:11)");
            Context.animation({
                duration: 500
            });
            TextInput.placeholderFont({ size: 12 });
            TextInput.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            TextInput.fontSize(12);
            TextInput.maxLength(10);
            TextInput.width(this.textInputWidth);
            TextInput.height(28);
            TextInput.onChange((val) => {
                this.searchText = val;
            });
            TextInput.visibility(this.isSearch ? Visibility.Visible : Visibility.None);
            Context.animation(null);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777269, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(197:11)");
            Image.width(24);
            Image.onClick(() => {
                if (this.isSearch == false) {
                    this.isSearch = !this.isSearch;
                    this.textInputWidth = 250;
                }
                else {
                    this.updateTaskLis_search();
                }
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 2 });
            Column.debugLine("pages/TaskIndex.ets(215:9)");
            Column.width('100%');
            Column.margin({ top: 30 });
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.taskList.length == 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('今日还没有家务哦，快去新建一个吧!');
                        Text.debugLine("pages/TaskIndex.ets(217:13)");
                        Text.fontSize(12);
                        Text.fontColor(Color.Gray);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('————家务列表————');
                        Text.debugLine("pages/TaskIndex.ets(221:13)");
                        Text.fontSize(12);
                        Text.fontColor(Color.Gray);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 10 });
            List.debugLine("pages/TaskIndex.ets(225:11)");
            List.alignListItem(ListItemAlign.Center);
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/TaskIndex.ets(227:15)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new taskListCom(this, { curIndex: index, curTask: item }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new taskListCom(this, { curIndex: index, curTask: item }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.taskList, forEachItemGenFunction, (item) => item.id.toString(), true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Column.pop();
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class taskListCom extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__taskList = this.initializeConsume("taskList", "taskList");
        this.curIndex = 0;
        this.__curTask = new ObservedPropertyObjectPU(null, this, "curTask");
        this.dialogController = new CustomDialogController({
            builder: () => {
                let jsDialog = new taskDetail(this, {
                    curTask: this.__curTask,
                    curIndex: this.curIndex
                });
                jsDialog.setController(this.dialogController);
                ViewPU.create(jsDialog);
            }
        }, this);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.curIndex !== undefined) {
            this.curIndex = params.curIndex;
        }
        if (params.curTask !== undefined) {
            this.curTask = params.curTask;
        }
        if (params.dialogController !== undefined) {
            this.dialogController = params.dialogController;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__curTask.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__taskList.aboutToBeDeleted();
        this.__curTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get taskList() {
        return this.__taskList.get();
    }
    set taskList(newValue) {
        this.__taskList.set(newValue);
    }
    get curTask() {
        return this.__curTask.get();
    }
    set curTask(newValue) {
        this.__curTask.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 3 });
            Row.debugLine("pages/TaskIndex.ets(263:5)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('90%');
            Row.height('7%');
            Row.border({ radius: 20 });
            Row.backgroundColor({ "id": 16777246, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Row.shadow({ radius: 10, color: Color.Gray });
            Row.onClick(() => {
                console.log('TaskDetail:' + JSON.stringify(ObservedObject.GetRawObject(this.curTask)));
                this.dialogController.open();
            });
            Row.padding(10);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.curTask.taskName + ' |');
            Text.debugLine("pages/TaskIndex.ets(264:7)");
            Text.width('30%');
            Text.fontWeight(FontWeight.Bold);
            Text.fontSize(24);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('' + this.curTask.date + '  ' + this.curTask.time);
            Text.debugLine("pages/TaskIndex.ets(269:7)");
            Text.width('40%');
            Text.fontSize(16);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.curTask.isDone) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Row.create({ space: 2 });
                        Row.debugLine("pages/TaskIndex.ets(275:9)");
                        if (!isInitialRender) {
                            Row.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('已完成');
                        Text.debugLine("pages/TaskIndex.ets(276:11)");
                        Text.fontSize(16);
                        Text.fontColor('#32C5FF');
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Image.create({ "id": 16777299, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        Image.debugLine("pages/TaskIndex.ets(280:11)");
                        Image.width(16);
                        if (!isInitialRender) {
                            Image.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('未完成');
                        Text.debugLine("pages/TaskIndex.ets(284:9)");
                        Text.fontSize(16);
                        Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class taskDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__taskList = this.initializeConsume("taskList", "taskList");
        this.curIndex = 0;
        this.__curTask = new SynchedPropertyObjectTwoWayPU(params.curTask, this, "curTask");
        this.controller = undefined;
        this.__finValue = new ObservedPropertyObjectPU([0, 0, 0, 0, 0], this, "finValue");
        this.__beizhuExpand = new ObservedPropertySimplePU(false, this, "beizhuExpand");
        this.__isAlarm = new ObservedPropertySimplePU(false, this, "isAlarm");
        this.__rating = new ObservedPropertySimplePU(0, this, "rating");
        this.__rating_show = new ObservedPropertySimplePU(false, this, "rating_show");
        this.__finValue_flower = new ObservedPropertySimplePU('0', this, "finValue_flower");
        this.__isDone = new ObservedPropertySimplePU(false, this, "isDone");
        this.setInitiallyProvidedValue(params);
        this.declareWatch("rating", this.onRatingChanged);
    }
    setInitiallyProvidedValue(params) {
        if (params.curIndex !== undefined) {
            this.curIndex = params.curIndex;
        }
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.finValue !== undefined) {
            this.finValue = params.finValue;
        }
        if (params.beizhuExpand !== undefined) {
            this.beizhuExpand = params.beizhuExpand;
        }
        if (params.isAlarm !== undefined) {
            this.isAlarm = params.isAlarm;
        }
        if (params.rating !== undefined) {
            this.rating = params.rating;
        }
        if (params.rating_show !== undefined) {
            this.rating_show = params.rating_show;
        }
        if (params.finValue_flower !== undefined) {
            this.finValue_flower = params.finValue_flower;
        }
        if (params.isDone !== undefined) {
            this.isDone = params.isDone;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__curTask.purgeDependencyOnElmtId(rmElmtId);
        this.__finValue.purgeDependencyOnElmtId(rmElmtId);
        this.__beizhuExpand.purgeDependencyOnElmtId(rmElmtId);
        this.__isAlarm.purgeDependencyOnElmtId(rmElmtId);
        this.__rating.purgeDependencyOnElmtId(rmElmtId);
        this.__rating_show.purgeDependencyOnElmtId(rmElmtId);
        this.__finValue_flower.purgeDependencyOnElmtId(rmElmtId);
        this.__isDone.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__taskList.aboutToBeDeleted();
        this.__curTask.aboutToBeDeleted();
        this.__finValue.aboutToBeDeleted();
        this.__beizhuExpand.aboutToBeDeleted();
        this.__isAlarm.aboutToBeDeleted();
        this.__rating.aboutToBeDeleted();
        this.__rating_show.aboutToBeDeleted();
        this.__finValue_flower.aboutToBeDeleted();
        this.__isDone.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get taskList() {
        return this.__taskList.get();
    }
    set taskList(newValue) {
        this.__taskList.set(newValue);
    }
    get curTask() {
        return this.__curTask.get();
    }
    set curTask(newValue) {
        this.__curTask.set(newValue);
    }
    setController(ctr) {
        this.controller = ctr;
    }
    get finValue() {
        return this.__finValue.get();
    }
    set finValue(newValue) {
        this.__finValue.set(newValue);
    }
    get beizhuExpand() {
        return this.__beizhuExpand.get();
    }
    set beizhuExpand(newValue) {
        this.__beizhuExpand.set(newValue);
    }
    get isAlarm() {
        return this.__isAlarm.get();
    }
    set isAlarm(newValue) {
        this.__isAlarm.set(newValue);
    }
    get rating() {
        return this.__rating.get();
    }
    set rating(newValue) {
        this.__rating.set(newValue);
    }
    get rating_show() {
        return this.__rating_show.get();
    }
    set rating_show(newValue) {
        this.__rating_show.set(newValue);
    }
    get finValue_flower() {
        return this.__finValue_flower.get();
    }
    set finValue_flower(newValue) {
        this.__finValue_flower.set(newValue);
    }
    get isDone() {
        return this.__isDone.get();
    }
    set isDone(newValue) {
        this.__isDone.set(newValue);
    }
    aboutToAppear() {
        this.taskFinValChanged();
        this.isAlarm = this.curTask.isAlarm;
        this.isDone = this.curTask.isDone;
    }
    taskFinValChanged() {
        let finValue_num = parseInt(this.curTask.finValue);
        finValue_num--;
        while (finValue_num >= 0) {
            this.finValue[finValue_num] = 1;
            finValue_num--;
        }
    }
    onRatingChanged() {
        let task_target_flower = parseInt(this.curTask.targetValue);
        this.finValue_flower = (Math.floor((this.rating / 5) * task_target_flower)).toString();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 2 });
            Column.debugLine("pages/TaskIndex.ets(339:5)");
            Column.height('50%');
            Column.width('90%');
            Column.margin(10);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(340:7)");
            Row.width('90%');
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('家务');
            Text.debugLine("pages/TaskIndex.ets(341:9)");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.curTask.taskName);
            Text.debugLine("pages/TaskIndex.ets(345:9)");
            Text.fontSize(24);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(353:7)");
            Row.width('90%');
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('预完成时间');
            Text.debugLine("pages/TaskIndex.ets(354:9)");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.curTask.date + '  ' + this.curTask.time);
            Text.debugLine("pages/TaskIndex.ets(358:9)");
            Text.fontSize(16);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(366:7)");
            Row.width('90%');
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('指定完成者');
            Text.debugLine("pages/TaskIndex.ets(367:9)");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.curTask.personName == '' ? '不限' : this.curTask.personName);
            Text.debugLine("pages/TaskIndex.ets(371:9)");
            Text.fontSize(16);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(380:7)");
            Row.width('90%');
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('满完成度奖励');
            Text.debugLine("pages/TaskIndex.ets(381:9)");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(385:9)");
            Row.width('30%');
            Row.justifyContent(FlexAlign.End);
            Row.margin({ bottom: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(386:11)");
            Image.width(16);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(` x ${this.curTask.targetValue == '' ? '不限' : this.curTask.targetValue}`);
            Text.debugLine("pages/TaskIndex.ets(389:11)");
            Text.fontSize(16);
            Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(401:7)");
            Row.width('90%');
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.curTask.isDone ? '已完成' : '未完成');
            Text.debugLine("pages/TaskIndex.ets(402:9)");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(this.curTask.isDone ? Color.Blue : { "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Text.margin({ right: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(408:9)");
            Row.width('40%');
            Row.justifyContent(FlexAlign.SpaceEvenly);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Image.create(this.curTask.isDone ? (item == 0 ? { "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" } : { "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" }) : { "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                    Image.debugLine("pages/TaskIndex.ets(410:13)");
                    Image.width(16);
                    if (!isInitialRender) {
                        Image.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
            };
            this.forEachUpdateFunction(elmtId, this.finValue, forEachItemGenFunction, (index) => index.toString(), true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        Row.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 2 });
            Column.debugLine("pages/TaskIndex.ets(421:7)");
            Column.width('90%');
            Column.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create({ space: 2 });
            Row.debugLine("pages/TaskIndex.ets(422:9)");
            Row.width('100%');
            Row.height(30);
            Row.onClick(() => { this.beizhuExpand = !this.beizhuExpand; });
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('备注');
            Text.debugLine("pages/TaskIndex.ets(423:11)");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(427:11)");
            Image.width(16);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.beizhuExpand) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create(this.curTask.beizhu == '' ? '无备注' : this.curTask.beizhu);
                        Text.debugLine("pages/TaskIndex.ets(436:11)");
                        Text.fontSize(13);
                        Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        Text.width('90%');
                        Text.margin(10);
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(446:7)");
            Row.width('90%');
            Row.height(30);
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('开启提醒');
            Text.debugLine("pages/TaskIndex.ets(447:9)");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.isAlarm ? { "id": 16777273, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" } : { "id": 16777264, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(451:9)");
            Image.width(16);
            Image.onClick(() => {
                var _a, _b, _c, _d, _e, _f;
                if (this.isAlarm == false) {
                    let context = getContext(this);
                    let reminder = new ReminderService();
                    try {
                        let publishReminderInfo = new ReminderItem();
                        publishReminderInfo.hour = Number((_a = this.curTask) === null || _a === void 0 ? void 0 : _a.time.split(':')[0]);
                        publishReminderInfo.minute = Number((_b = this.curTask) === null || _b === void 0 ? void 0 : _b.time.split(':')[1]);
                        publishReminderInfo.year = Number((_c = this.curTask) === null || _c === void 0 ? void 0 : _c.date.split('-')[0]);
                        publishReminderInfo.month = Number((_d = this.curTask) === null || _d === void 0 ? void 0 : _d.date.split('-')[1]);
                        publishReminderInfo.day = Number((_e = this.curTask) === null || _e === void 0 ? void 0 : _e.date.split('-')[2]);
                        publishReminderInfo.title = this.curTask.taskName;
                        publishReminderInfo.content = this.curTask.beizhu;
                        publishReminderInfo.notificationId = (_f = this.curTask) === null || _f === void 0 ? void 0 : _f.taskID;
                        console.log(`提醒年 ${publishReminderInfo.year} 月 ${publishReminderInfo.month} 时分 ${publishReminderInfo.hour} : ${publishReminderInfo.minute} id ${publishReminderInfo.notificationId}`);
                        reminder.addReminder(publishReminderInfo, context, (newId) => { this.curTask.taskID = newId; Prompt.showToast({ message: '添加提醒成功' }); });
                        this.isAlarm = true;
                        //更新数据库
                        //修改curTask,taskList
                        this.taskList[this.curIndex].isAlarm = this.curTask.isAlarm = true;
                        TaskInfoApi.updateDataByDate(ObservedObject.GetRawObject(this.curTask), () => {
                        });
                    }
                    catch (error) {
                        Logger.error('publishReminder', JSON.stringify(error));
                    }
                }
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 4 });
            Column.debugLine("pages/TaskIndex.ets(487:7)");
            Column.width('100%');
            Column.height('30%');
            Column.justifyContent(FlexAlign.Center);
            Column.margin({ bottom: 10 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.rating_show && !this.isDone) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Rating.create({ rating: this.rating });
                        Rating.debugLine("pages/TaskIndex.ets(490:11)");
                        Rating.stars(5);
                        Rating.stepSize(1);
                        Rating.onChange((val) => {
                            this.rating = val;
                        });
                        Rating.width('60%');
                        Rating.height(30);
                        Rating.margin({ top: 10 });
                        if (!isInitialRender) {
                            Rating.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Rating.pop();
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        Text.create('可获得鲜花 x ' + this.finValue_flower);
                        Text.debugLine("pages/TaskIndex.ets(500:11)");
                        Text.fontSize(16);
                        Text.fontColor({ "id": 16777243, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                        if (!isInitialRender) {
                            Text.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    Text.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskIndex.ets(506:9)");
            Row.width('90%');
            Row.justifyContent(FlexAlign.SpaceEvenly);
            Row.margin({ top: 10 });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (!this.isDone) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        If.create();
                        if (!this.rating_show) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation((elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    Image.create({ "id": 16777260, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
                                    Image.debugLine("pages/TaskIndex.ets(509:15)");
                                    Image.width(40);
                                    Image.onClick(() => {
                                        this.rating_show = !this.rating_show;
                                    });
                                    if (!isInitialRender) {
                                        Image.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                });
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation((elmtId, isInitialRender) => {
                                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                    Button.createWithLabel('确定');
                                    Button.debugLine("pages/TaskIndex.ets(515:15)");
                                    Button.type(ButtonType.Capsule);
                                    Button.width(80);
                                    Button.height(44);
                                    Button.backgroundColor(Color.Green);
                                    Button.fontSize(16);
                                    Button.fontColor(Color.White);
                                    Button.onClick(() => {
                                        //修改curTask,taskList
                                        this.taskList[this.curIndex].finValue = this.curTask.finValue = this.rating.toString();
                                        this.taskList[this.curIndex].isDone = this.curTask.isDone = true;
                                        this.isDone = true;
                                        TaskInfoApi.updateDataByDate(ObservedObject.GetRawObject(this.curTask), () => {
                                            Prompt.showToast({ message: '完成家务！' });
                                        });
                                        this.taskFinValChanged();
                                        //修改完成者的鲜花
                                        if (this.curTask.personName != '' && this.curTask.personName != '不限') {
                                            let oP = PersonList.queryByName(this.curTask.personName);
                                            oP.personValue += parseInt(this.finValue_flower);
                                            PersonList.updatePerson(oP);
                                            PersonInfoApi.updateDataByName(oP, () => {
                                            });
                                        }
                                    });
                                    if (!isInitialRender) {
                                        Button.pop();
                                    }
                                    ViewStackProcessor.StopGetAccessRecording();
                                });
                                Button.pop();
                            });
                        }
                        if (!isInitialRender) {
                            If.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                    If.pop();
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777283, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/TaskIndex.ets(548:11)");
            Image.width(40);
            Image.onClick(() => {
                this.taskList.splice(this.curIndex, 1);
                TaskInfoApi.deleteDataByID(ObservedObject.GetRawObject(this.curTask), () => {
                    Prompt.showToast({ message: '删除成功' });
                });
                this.controller.close();
            });
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(1, "TaskIndex", new TaskIndex(undefined, {}));
}
//# sourceMappingURL=TaskIndex.js.map