import { TaskIndex } from '@bundle:com.example.houseworkapp/entry/ets/pages/TaskIndex';
import { JiatingIndex } from '@bundle:com.example.houseworkapp/entry/ets/pages/JiatingIndex';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__currentPage = new ObservedPropertySimplePU(0, this, "currentPage");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentPage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue) {
        this.__currentPage.set(newValue);
    }
    TabBuilder_Task(index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(23:5)");
            Column.justifyContent(FlexAlign.Center);
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(index == this.currentPage ? { "id": 16777282, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" } : { "id": 16777259, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(24:7)");
            Image.width(24);
            Image.height(24);
            Image.objectFit(ImageFit.Contain);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('家务');
            Text.debugLine("pages/Index.ets(28:7)");
            Text.fontSize(10);
            Text.fontWeight(500);
            Text.fontColor(this.currentPage === index ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" } : { "id": 16777240, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Text.margin({ top: 4 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    TabBuilder_Jiating(index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Index.ets(39:5)");
            Column.justifyContent(FlexAlign.Center);
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(index == this.currentPage ? { "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" } : { "id": 16777271, "type": 20000, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(40:7)");
            Image.width(24);
            Image.height(24);
            Image.objectFit(ImageFit.Contain);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('家庭');
            Text.debugLine("pages/Index.ets(44:7)");
            Text.fontSize(10);
            Text.fontWeight(500);
            Text.fontColor(this.currentPage === index ? { "id": 16777220, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" } : { "id": 16777240, "type": 10001, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" });
            Text.margin({ top: 4 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("pages/Index.ets(55:5)");
            Tabs.scrollable(false);
            Tabs.width('100%');
            Tabs.height('100%');
            Tabs.barWidth('94%');
            Tabs.barMode(BarMode.Fixed);
            Tabs.vertical(false);
            Tabs.onChange((index) => {
                this.currentPage = index;
            });
            if (!isInitialRender) {
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new TaskIndex(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder_Task.call(this, 0);
                } });
            TabContent.debugLine("pages/Index.ets(56:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TabContent.create(() => {
                {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        if (isInitialRender) {
                            ViewPU.create(new JiatingIndex(this, {}, undefined, elmtId));
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                }
            });
            TabContent.tabBar({ builder: () => {
                    this.TabBuilder_Jiating.call(this, 1);
                } });
            TabContent.debugLine("pages/Index.ets(61:7)");
            if (!isInitialRender) {
                TabContent.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        TabContent.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Index.js.map