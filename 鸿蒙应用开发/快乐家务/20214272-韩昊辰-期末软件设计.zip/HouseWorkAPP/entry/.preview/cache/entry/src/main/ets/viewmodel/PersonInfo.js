export default class PersonInfo {
    constructor(personName, personStatus, personValue) {
        this.personName = '';
        this.personValue = 0;
        this.personStatus = '';
        this.personName = personName;
        this.personValue = personValue;
        this.personStatus = personStatus;
    }
}
//# sourceMappingURL=PersonInfo.js.map