/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License,Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import dataRdb from '@ohos:data.relationalStore';
import TaskInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/TaskInfo';
import { CommonConstants as Const } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
import RdbUtils from '@bundle:com.example.houseworkapp/entry/ets/database/rdb/RdbUtils';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
class TaskInfoApi {
    /**
     * insert taskInfo
     *
     * @param taskInfo
     * @param callback
     */
    insertData(taskInfo, callback) {
        console.log('insertTask:');
        taskInfo.toInfo();
        const valueBucket = generateBucket(taskInfo);
        RdbUtils.insert('taskInfo', valueBucket).then(result => {
            callback(result);
        });
        Logger.info('TaskInfoTable', `Insert taskInfo {${taskInfo.date}:${taskInfo.taskID}} finished.`);
    }
    /**
     * delete taskInfo
     *
     * @param taskInfo
     * @param callback
     */
    deleteDataByID(taskInfo, callback) {
        let tableName = Const.TASK_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('date', taskInfo.date).and().equalTo('taskID', taskInfo.taskID).and().equalTo('taskName', taskInfo.taskName);
        RdbUtils.del(predicates).then(result => {
            callback(result);
        });
        Logger.info('TaskInfoTable', `Delete taskInfo {${taskInfo.date}:${taskInfo.taskID}} finished.`);
    }
    /**
     * update taskInfo
     *
     * @param taskInfo
     * @param callback
     */
    updateDataByDate(taskInfo, callback) {
        const valueBucket = generateBucket(taskInfo);
        let tableName = Const.TASK_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('date', taskInfo.date).and().equalTo('taskID', taskInfo.taskID).and().equalTo('taskName', taskInfo.taskName);
        RdbUtils.update(valueBucket, predicates).then((result) => {
            callback(result);
        });
        Logger.info('TaskInfoTable', `Update data {${taskInfo.date}:${taskInfo.taskID}} finished.`);
    }
    /**
     * query taskInfo
     *
     * @param date
     * @param callback
     */
    query_debug(date, callback) {
        let tableName = Const.TASK_INFO.tableName;
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('date', date);
        RdbUtils.query(predicates).then(resultSet => {
            let count = resultSet.rowCount;
            console.log('query_debug,count:', count);
            if (count === 0 || typeof count === 'string') {
                Logger.error('TaskInfoTable', `${date} query no results!`);
                const result = [];
                callback(result);
            }
            else {
                resultSet.goToFirstRow();
                const result = [];
                for (let i = 0; i < count; i++) {
                    let tmp = new TaskInfo(0, '', 0, '', false, '', '', '', false, '', false, '', '', '', '');
                    tmp.isOpen = resultSet.getDouble(resultSet.getColumnIndex('isOpen')) ? true : false;
                    tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
                    tmp.date = resultSet.getString(resultSet.getColumnIndex('date'));
                    tmp.taskID = resultSet.getDouble(resultSet.getColumnIndex('taskID'));
                    tmp.targetValue = resultSet.getString(resultSet.getColumnIndex('targetValue'));
                    tmp.isAlarm = resultSet.getDouble(resultSet.getColumnIndex('isAlarm')) ? true : false;
                    tmp.startTime = resultSet.getString(resultSet.getColumnIndex('startTime'));
                    tmp.endTime = resultSet.getString(resultSet.getColumnIndex('endTime'));
                    tmp.frequency = resultSet.getString(resultSet.getColumnIndex('frequency'));
                    tmp.isDone = resultSet.getDouble(resultSet.getColumnIndex('isDone')) ? true : false;
                    tmp.finValue = resultSet.getString(resultSet.getColumnIndex('finValue'));
                    tmp.personName = resultSet.getString(resultSet.getColumnIndex('personName'));
                    tmp.time = resultSet.getString(resultSet.getColumnIndex('time'));
                    tmp.beizhu = resultSet.getString(resultSet.getColumnIndex('beizhu'));
                    tmp.taskName = resultSet.getString(resultSet.getColumnIndex('taskName'));
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);
            }
        });
    }
    query(date, isOpen = true, callback) {
        console.log('queryTask: date=' + date + 'isOpen=' + isOpen ? 'true' : 'false');
        let tableName = Const.TASK_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('date', date);
        if (isOpen) {
            predicates.equalTo('isOpen', true);
        }
        // predicates.orderByAsc('taskID');
        RdbUtils.query(predicates).then(resultSet => {
            let count = resultSet.rowCount;
            if (count === 0 || typeof count === 'string') {
                Logger.error('TaskInfoTable', `${date} query no results!`);
                const result = [];
                callback(result);
            }
            else {
                resultSet.goToFirstRow();
                const result = [];
                for (let i = 0; i < count; i++) {
                    let tmp = new TaskInfo(0, '', 0, '', false, '', '', '', false, '', false, '', '', '', '');
                    tmp.isOpen = resultSet.getDouble(resultSet.getColumnIndex('isOpen')) ? true : false;
                    tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
                    tmp.date = resultSet.getString(resultSet.getColumnIndex('date'));
                    tmp.taskID = resultSet.getDouble(resultSet.getColumnIndex('taskID'));
                    tmp.targetValue = resultSet.getString(resultSet.getColumnIndex('targetValue'));
                    tmp.isAlarm = resultSet.getDouble(resultSet.getColumnIndex('isAlarm')) ? true : false;
                    tmp.startTime = resultSet.getString(resultSet.getColumnIndex('startTime'));
                    tmp.endTime = resultSet.getString(resultSet.getColumnIndex('endTime'));
                    tmp.frequency = resultSet.getString(resultSet.getColumnIndex('frequency'));
                    tmp.isDone = resultSet.getDouble(resultSet.getColumnIndex('isDone')) ? true : false;
                    tmp.finValue = resultSet.getString(resultSet.getColumnIndex('finValue'));
                    tmp.personName = resultSet.getString(resultSet.getColumnIndex('personName'));
                    tmp.time = resultSet.getString(resultSet.getColumnIndex('time'));
                    tmp.beizhu = resultSet.getString(resultSet.getColumnIndex('beizhu'));
                    tmp.taskName = resultSet.getString(resultSet.getColumnIndex('taskName'));
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);
            }
        });
    }
    query_date(date, callback, personName, isDone, order) {
        console.log('queryTask: date=' + date);
        let tableName = Const.TASK_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.equalTo('date', date);
        if (personName != null && personName != '' && personName != '不限') {
            predicates.equalTo('personName', personName);
            console.log('predicates.equalTo(personName)');
        }
        if (isDone != null) {
            predicates.and().equalTo('isDone', isDone);
            console.log('predicates.equalTo(isDone)');
        }
        if (order != '' && order != null) {
            predicates.and().orderByAsc(order);
        }
        RdbUtils.query(predicates).then(resultSet => {
            let count = resultSet.rowCount;
            if (count === 0 || typeof count === 'string') {
                Logger.error('TaskInfoTable', `${date} query no results!`);
                const result = [];
                callback(result);
            }
            else {
                resultSet.goToFirstRow();
                const result = [];
                for (let i = 0; i < count; i++) {
                    let tmp = new TaskInfo(0, '', 0, '', false, '', '', '', false, '', false, '', '', '', '');
                    tmp.isOpen = resultSet.getDouble(resultSet.getColumnIndex('isOpen')) ? true : false;
                    tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
                    tmp.date = resultSet.getString(resultSet.getColumnIndex('date'));
                    tmp.taskID = resultSet.getDouble(resultSet.getColumnIndex('taskID'));
                    tmp.targetValue = resultSet.getString(resultSet.getColumnIndex('targetValue'));
                    tmp.isAlarm = resultSet.getDouble(resultSet.getColumnIndex('isAlarm')) ? true : false;
                    tmp.startTime = resultSet.getString(resultSet.getColumnIndex('startTime'));
                    tmp.endTime = resultSet.getString(resultSet.getColumnIndex('endTime'));
                    tmp.frequency = resultSet.getString(resultSet.getColumnIndex('frequency'));
                    tmp.isDone = resultSet.getDouble(resultSet.getColumnIndex('isDone')) ? true : false;
                    tmp.finValue = resultSet.getString(resultSet.getColumnIndex('finValue'));
                    tmp.personName = resultSet.getString(resultSet.getColumnIndex('personName'));
                    tmp.taskName = resultSet.getString(resultSet.getColumnIndex('taskName'));
                    tmp.time = resultSet.getString(resultSet.getColumnIndex('time'));
                    tmp.beizhu = resultSet.getString(resultSet.getColumnIndex('beizhu'));
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);
            }
        });
    }
    query_search(searchText, callback) {
        console.log('queryTask: searchText=' + searchText);
        let tableName = Const.TASK_INFO.tableName;
        if (!tableName) {
            return;
        }
        let predicates = new dataRdb.RdbPredicates(tableName);
        predicates.contains('taskName', searchText).or();
        predicates.contains('beizhu', searchText).or();
        predicates.contains('personName', searchText);
        RdbUtils.query(predicates).then(resultSet => {
            let count = resultSet.rowCount;
            if (count === 0 || typeof count === 'string') {
                Logger.error('TaskInfoTable', `${searchText} query no results!`);
                const result = [];
                callback(result);
            }
            else {
                resultSet.goToFirstRow();
                const result = [];
                for (let i = 0; i < count; i++) {
                    let tmp = new TaskInfo(0, '', 0, '', false, '', '', '', false, '', false, '', '', '', '');
                    tmp.isOpen = resultSet.getDouble(resultSet.getColumnIndex('isOpen')) ? true : false;
                    tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
                    tmp.date = resultSet.getString(resultSet.getColumnIndex('date'));
                    tmp.taskID = resultSet.getDouble(resultSet.getColumnIndex('taskID'));
                    tmp.targetValue = resultSet.getString(resultSet.getColumnIndex('targetValue'));
                    tmp.isAlarm = resultSet.getDouble(resultSet.getColumnIndex('isAlarm')) ? true : false;
                    tmp.startTime = resultSet.getString(resultSet.getColumnIndex('startTime'));
                    tmp.endTime = resultSet.getString(resultSet.getColumnIndex('endTime'));
                    tmp.frequency = resultSet.getString(resultSet.getColumnIndex('frequency'));
                    tmp.isDone = resultSet.getDouble(resultSet.getColumnIndex('isDone')) ? true : false;
                    tmp.finValue = resultSet.getString(resultSet.getColumnIndex('finValue'));
                    tmp.taskName = resultSet.getString(resultSet.getColumnIndex('taskName'));
                    tmp.personName = resultSet.getString(resultSet.getColumnIndex('personName'));
                    tmp.time = resultSet.getString(resultSet.getColumnIndex('time'));
                    tmp.beizhu = resultSet.getString(resultSet.getColumnIndex('beizhu'));
                    result[i] = tmp;
                    resultSet.goToNextRow();
                }
                callback(result);
            }
        });
    }
}
function generateBucket(taskInfo) {
    var _a;
    let valueBucket = {};
    (_a = Const.TASK_INFO.columns) === null || _a === void 0 ? void 0 : _a.forEach((item) => {
        if (item !== 'id') {
            switch (item) {
                case 'date':
                    valueBucket[item] = taskInfo.date;
                    break;
                case 'taskID':
                    valueBucket[item] = taskInfo.taskID;
                    break;
                case 'targetValue':
                    valueBucket[item] = taskInfo.targetValue;
                    break;
                case 'isAlarm':
                    valueBucket[item] = taskInfo.isAlarm;
                    break;
                case 'startTime':
                    valueBucket[item] = taskInfo.startTime;
                    break;
                case 'endTime':
                    valueBucket[item] = taskInfo.endTime;
                    break;
                case 'frequency':
                    valueBucket[item] = taskInfo.frequency;
                    break;
                case 'isDone':
                    valueBucket[item] = taskInfo.isDone;
                    break;
                case 'finValue':
                    valueBucket[item] = taskInfo.finValue;
                    break;
                case 'isOpen':
                    valueBucket[item] = taskInfo.isOpen;
                    break;
                case 'personName':
                    valueBucket[item] = taskInfo.personName;
                    break;
                case 'time':
                    valueBucket[item] = taskInfo.time;
                    break;
                case 'beizhu':
                    valueBucket[item] = taskInfo.beizhu;
                    break;
                case 'taskName':
                    valueBucket[item] = taskInfo.taskName;
                    break;
                default:
                    break;
            }
        }
    });
    return valueBucket;
}
let taskInfoApi = new TaskInfoApi();
export default taskInfoApi;
//# sourceMappingURL=TaskInfoApi.js.map