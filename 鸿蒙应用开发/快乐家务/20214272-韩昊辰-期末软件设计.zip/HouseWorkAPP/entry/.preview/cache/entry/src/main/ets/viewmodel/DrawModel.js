/*
 * Copyright (c) 2023 Huawei Device Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the 'License');
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an 'AS IS' BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import { CommonConstants } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
import { EnumeratedValue } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
import ColorConstants from '@bundle:com.example.houseworkapp/entry/ets/constants/ColorConstants';
import StyleConstants from '@bundle:com.example.houseworkapp/entry/ets/constants/StyleConstants';
import PrizeData from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/PrizeData';
import FillArcData from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/FillArcData';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
import CheckEmptyUtils from '@bundle:com.example.houseworkapp/entry/ets/utils/CheckEmptyUtils';
/**
 * Canvas drawing method class.
 */
export default class DrawModel {
    constructor() {
        this.startAngle = 0;
        this.avgAngle = CommonConstants.CIRCLE / CommonConstants.COUNT;
        this.screenWidth = 0;
    }
    /**
     * Draw the raffle round turntable.
     *
     * @param canvasContext canvasContext.
     * @param screenWidth screenWidth.
     * @param screenHeight screenHeight.
     */
    draw(canvasContext, screenWidth, screenHeight) {
        if (CheckEmptyUtils.isEmptyObj(canvasContext)) {
            Logger.error('[DrawModel][draw] canvasContext is empty.');
            return;
        }
        this.canvasContext = canvasContext;
        this.screenWidth = screenWidth;
        this.canvasContext.clearRect(0, 0, this.screenWidth, screenHeight);
        // Translates the canvas along the X and Y axes by a specified distance.
        this.canvasContext.translate(this.screenWidth / CommonConstants.TWO, screenHeight / CommonConstants.TWO);
        // Painted outer disc petal.
        this.drawFlower();
        // Draw outer disc, small circle.
        this.drawOutCircle();
        // Draw the inner disc.
        this.drawInnerCircle();
        // Draw the interior fan-shaped raffle area.
        this.drawInnerArc();
        // Draw text in the internal fan area.
        this.drawArcText();
        // Draw the picture corresponding to the prize in the internal fan area.
        this.drawImage();
        this.canvasContext.translate(-this.screenWidth / CommonConstants.TWO, -screenHeight / CommonConstants.TWO);
    }
    /**
     * Method of drawing arcs.
     *
     * @param fillArcData fillArcData.
     * @param fillColor fillColor.
     */
    fillArc(fillArcData, fillColor) {
        if (CheckEmptyUtils.isEmptyObj(fillArcData) || CheckEmptyUtils.isEmptyStr(fillColor)) {
            Logger.error('[DrawModel][fillArc] fillArcData or fillColor is empty.');
            return;
        }
        if (this.canvasContext !== undefined) {
            this.canvasContext.beginPath();
            this.canvasContext.fillStyle = fillColor;
            this.canvasContext.arc(fillArcData.x, fillArcData.y, fillArcData.radius, fillArcData.startAngle, fillArcData.endAngle);
            this.canvasContext.fill();
        }
    }
    /**
     * Painted outer disc petal.
     */
    drawFlower() {
        var _a, _b, _c;
        let beginAngle = this.startAngle + this.avgAngle;
        const pointY = this.screenWidth * CommonConstants.FLOWER_POINT_Y_RATIOS;
        const radius = this.screenWidth * CommonConstants.FLOWER_RADIUS_RATIOS;
        const innerRadius = this.screenWidth * CommonConstants.FLOWER_INNER_RATIOS;
        for (let i = 0; i < CommonConstants.COUNT; i++) {
            (_a = this.canvasContext) === null || _a === void 0 ? void 0 : _a.save();
            (_b = this.canvasContext) === null || _b === void 0 ? void 0 : _b.rotate(beginAngle * Math.PI / CommonConstants.HALF_CIRCLE);
            this.fillArc(new FillArcData(0, -pointY, radius, 0, Math.PI * CommonConstants.TWO), ColorConstants.FLOWER_OUT_COLOR);
            this.fillArc(new FillArcData(0, -pointY, innerRadius, 0, Math.PI * CommonConstants.TWO), ColorConstants.FLOWER_INNER_COLOR);
            beginAngle += this.avgAngle;
            (_c = this.canvasContext) === null || _c === void 0 ? void 0 : _c.restore();
        }
    }
    /**
     * Draw outer disc, small circle.
     */
    drawOutCircle() {
        var _a, _b, _c;
        // Draw outer disc.
        this.fillArc(new FillArcData(0, 0, this.screenWidth * CommonConstants.OUT_CIRCLE_RATIOS, 0, Math.PI * CommonConstants.TWO), ColorConstants.OUT_CIRCLE_COLOR);
        let beginAngle = this.startAngle;
        // Draw small circle.
        for (let i = 0; i < CommonConstants.SMALL_CIRCLE_COUNT; i++) {
            (_a = this.canvasContext) === null || _a === void 0 ? void 0 : _a.save();
            (_b = this.canvasContext) === null || _b === void 0 ? void 0 : _b.rotate(beginAngle * Math.PI / CommonConstants.HALF_CIRCLE);
            this.fillArc(new FillArcData(this.screenWidth * CommonConstants.SMALL_CIRCLE_RATIOS, 0, CommonConstants.SMALL_CIRCLE_RADIUS, 0, Math.PI * CommonConstants.TWO), ColorConstants.WHITE_COLOR);
            beginAngle = beginAngle + CommonConstants.CIRCLE / CommonConstants.SMALL_CIRCLE_COUNT;
            (_c = this.canvasContext) === null || _c === void 0 ? void 0 : _c.restore();
        }
    }
    /**
     * Draw the inner disc.
     */
    drawInnerCircle() {
        this.fillArc(new FillArcData(0, 0, this.screenWidth * CommonConstants.INNER_CIRCLE_RATIOS, 0, Math.PI * CommonConstants.TWO), ColorConstants.INNER_CIRCLE_COLOR);
        this.fillArc(new FillArcData(0, 0, this.screenWidth * CommonConstants.INNER_WHITE_CIRCLE_RATIOS, 0, Math.PI * CommonConstants.TWO), ColorConstants.WHITE_COLOR);
    }
    /**
     * Draw the interior fan-shaped raffle area.
     */
    drawInnerArc() {
        var _a, _b;
        let colors = [
            ColorConstants.ARC_PINK_COLOR, ColorConstants.ARC_YELLOW_COLOR,
            ColorConstants.ARC_GREEN_COLOR, ColorConstants.ARC_PINK_COLOR,
            ColorConstants.ARC_YELLOW_COLOR, ColorConstants.ARC_GREEN_COLOR
        ];
        let radius = this.screenWidth * CommonConstants.INNER_ARC_RATIOS;
        for (let i = 0; i < CommonConstants.COUNT; i++) {
            this.fillArc(new FillArcData(0, 0, radius, this.startAngle * Math.PI / CommonConstants.HALF_CIRCLE, (this.startAngle + this.avgAngle) * Math.PI / CommonConstants.HALF_CIRCLE), colors[i]);
            (_a = this.canvasContext) === null || _a === void 0 ? void 0 : _a.lineTo(0, 0);
            (_b = this.canvasContext) === null || _b === void 0 ? void 0 : _b.fill();
            this.startAngle += this.avgAngle;
        }
    }
    /**
     * Draw text in the internal fan area.
     */
    drawArcText() {
        if (this.canvasContext !== undefined) {
            this.canvasContext.textAlign = CommonConstants.TEXT_ALIGN;
            this.canvasContext.textBaseline = CommonConstants.TEXT_BASE_LINE;
            this.canvasContext.fillStyle = ColorConstants.TEXT_COLOR;
            this.canvasContext.font = StyleConstants.ARC_TEXT_SIZE + CommonConstants.CANVAS_FONT;
        }
        let textArrays = [
            '电影',
            '玩具',
            'KFC',
            '泡脚',
            '唱歌',
            '谢谢'
        ];
        let arcTextStartAngle = CommonConstants.ARC_START_ANGLE;
        let arcTextEndAngle = CommonConstants.ARC_END_ANGLE;
        for (let i = 0; i < CommonConstants.COUNT; i++) {
            this.drawCircularText((textArrays[i]), (this.startAngle + arcTextStartAngle) * Math.PI / CommonConstants.HALF_CIRCLE, (this.startAngle + arcTextEndAngle) * Math.PI / CommonConstants.HALF_CIRCLE);
            this.startAngle += this.avgAngle;
        }
    }
    /**
     * Obtains the character string corresponding to the specified resource ID.
     *
     * @param resource resource.
     */
    getResourceString(resource) {
        if (CheckEmptyUtils.isEmptyObj(resource)) {
            Logger.error('[DrawModel][getResourceString] resource is empty.');
            return '';
        }
        let resourceString = '';
        try {
            resourceString = getContext(this).resourceManager.getStringSync(resource.id);
        }
        catch (error) {
            Logger.error(`[DrawModel][getResourceString]getStringSync failed, error : ${JSON.stringify(error)}.`);
        }
        return resourceString;
    }
    /**
     * Draw Arc Text.
     *
     * @param textString textString.
     * @param startAngle startAngle.
     * @param endAngle endAngle.
     */
    drawCircularText(textString, startAngle, endAngle) {
        var _a, _b, _c, _d, _e, _f;
        if (CheckEmptyUtils.isEmptyStr(textString)) {
            Logger.error('[DrawModel][drawCircularText] textString is empty.');
            return;
        }
        class CircleText {
            constructor() {
                this.x = 0;
                this.y = 0;
                this.radius = 0;
            }
        }
        let circleText = {
            x: 0,
            y: 0,
            radius: this.screenWidth * CommonConstants.INNER_ARC_RATIOS
        };
        // The radius of the circle.
        let radius = circleText.radius - circleText.radius / CommonConstants.COUNT;
        // The radians occupied by each letter.
        let angleDecrement = (startAngle - endAngle) / (textString.length - 1);
        let angle = startAngle;
        let index = 0;
        let character;
        while (index < textString.length) {
            character = textString.charAt(index);
            (_a = this.canvasContext) === null || _a === void 0 ? void 0 : _a.save();
            (_b = this.canvasContext) === null || _b === void 0 ? void 0 : _b.beginPath();
            (_c = this.canvasContext) === null || _c === void 0 ? void 0 : _c.translate(circleText.x + Math.cos(angle) * radius, circleText.y - Math.sin(angle) * radius);
            (_d = this.canvasContext) === null || _d === void 0 ? void 0 : _d.rotate(Math.PI / CommonConstants.TWO - angle);
            (_e = this.canvasContext) === null || _e === void 0 ? void 0 : _e.fillText(character, 0, 0);
            angle -= angleDecrement;
            index++;
            (_f = this.canvasContext) === null || _f === void 0 ? void 0 : _f.restore();
        }
    }
    /**
     * Draw the picture corresponding to the prize in the internal fan area.
     */
    drawImage() {
        var _a, _b, _c, _d;
        let beginAngle = this.startAngle;
        let imageSrc = [
            CommonConstants.WATERMELON_IMAGE_URL, CommonConstants.BEER_IMAGE_URL,
            CommonConstants.SMILE_IMAGE_URL, CommonConstants.CAKE_IMAGE_URL,
            CommonConstants.HAMBURG_IMAGE_URL, CommonConstants.SMILE_IMAGE_URL
        ];
        for (let i = 0; i < CommonConstants.COUNT; i++) {
            let image = new ImageBitmap(imageSrc[i]);
            (_a = this.canvasContext) === null || _a === void 0 ? void 0 : _a.save();
            (_b = this.canvasContext) === null || _b === void 0 ? void 0 : _b.rotate(beginAngle * Math.PI / CommonConstants.HALF_CIRCLE);
            (_c = this.canvasContext) === null || _c === void 0 ? void 0 : _c.drawImage(image, this.screenWidth * CommonConstants.IMAGE_DX_RATIOS, this.screenWidth * CommonConstants.IMAGE_DY_RATIOS, CommonConstants.IMAGE_SIZE, CommonConstants.IMAGE_SIZE);
            beginAngle += this.avgAngle;
            (_d = this.canvasContext) === null || _d === void 0 ? void 0 : _d.restore();
        }
    }
    /**
     * Displaying information about prizes.
     *
     * @param randomAngle randomAngle.
     */
    showPrizeData(randomAngle) {
        for (let i = 1; i <= CommonConstants.COUNT; i++) {
            if (randomAngle <= i * this.avgAngle) {
                return this.getPrizeData(i);
            }
        }
        return new PrizeData();
    }
    /**
     * Obtaining information about prizes.
     *
     * @param scopeNum scopeNum.
     */
    // '电影',
    // '玩具',
    // 'KFC',
    // '泡脚',
    // '唱歌',
    // '谢谢'
    getPrizeData(scopeNum) {
        let prizeData = new PrizeData();
        switch (scopeNum) {
            case EnumeratedValue.ONE:
                prizeData.message = { "id": 16777290, "type": 10003, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" };
                prizeData.imageSrc = CommonConstants.WATERMELON_IMAGE_URL;
                break;
            case EnumeratedValue.TWO:
                prizeData.message = { "id": 16777286, "type": 10003, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" };
                prizeData.imageSrc = CommonConstants.BEER_IMAGE_URL;
                break;
            case EnumeratedValue.THREE:
                prizeData.message = $r('app.string.dianying');
                prizeData.imageSrc = CommonConstants.SMILE_IMAGE_URL;
                break;
            case EnumeratedValue.FOUR:
                prizeData.message = { "id": 16777287, "type": 10003, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" };
                prizeData.imageSrc = CommonConstants.CAKE_IMAGE_URL;
                break;
            case EnumeratedValue.FIVE:
                prizeData.message = { "id": 16777288, "type": 10003, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" };
                prizeData.imageSrc = CommonConstants.HAMBURG_IMAGE_URL;
                break;
            case EnumeratedValue.SIX:
                prizeData.message = { "id": 16777289, "type": 10003, params: [], "bundleName": "com.example.houseworkapp", "moduleName": "entry" };
                prizeData.imageSrc = CommonConstants.SMILE_IMAGE_URL;
                break;
            default:
                break;
        }
        return prizeData;
    }
}
//# sourceMappingURL=DrawModel.js.map