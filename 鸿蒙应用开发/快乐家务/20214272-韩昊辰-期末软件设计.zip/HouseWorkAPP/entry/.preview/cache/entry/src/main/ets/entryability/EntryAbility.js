import UIAbility from '@ohos:app.ability.UIAbility';
import hilog from '@ohos:hilog';
import RdbUtils from '@bundle:com.example.houseworkapp/entry/ets/database/rdb/RdbUtils';
import { columnDayInfoList, columnFormInfoList, columnGlobalInfoList, columnPersonInfoList, columnPrayInfoList, columnTaskInfoInfoList } from '@bundle:com.example.houseworkapp/entry/ets/model/RdbColumnModel';
import { GlobalContext } from '@bundle:com.example.houseworkapp/entry/ets/utils/GlobalContext';
import Logger from '@bundle:com.example.houseworkapp/entry/ets/utils/Logger';
import { CommonConstants as Const } from '@bundle:com.example.houseworkapp/entry/ets/constants/CommonConstants';
import { PersonList } from '@bundle:com.example.houseworkapp/entry/ets/utils/PersonList';
import PersonInfoApi from '@bundle:com.example.houseworkapp/entry/ets/database/tables/PersonInfoApi';
import PersonInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/PersonInfo';
export default class EntryAbility extends UIAbility {
    async onCreate(want, launchParam) {
        // hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
        GlobalContext.getContext().setObject('want', want);
        GlobalContext.getContext().setObject('launchParam', launchParam);
        RdbUtils.initDb(this.context, Const.RDB_NAME.dbName ? Const.RDB_NAME.dbName : '');
        await RdbUtils.createDb();
        //创建各种数据表
        RdbUtils.createTable('dayInfo', columnDayInfoList).then(() => {
            Logger.info(`RdbHelper createTable dayInfo success`);
        }).catch((err) => {
            Logger.error(`RdbHelper dayInfo err : ${JSON.stringify(err)}`);
        });
        RdbUtils.createTable('globalInfo', columnGlobalInfoList).then(() => {
            Logger.info(`RdbHelper createTable globalInfo success`);
        }).catch((err) => {
            Logger.error(`RdbHelper globalInfo err : ${JSON.stringify(err)}`);
        });
        RdbUtils.createTable('taskInfo', columnTaskInfoInfoList).then(() => {
            Logger.info(`RdbHelper createTable taskInfo success`);
        }).catch((err) => {
            Logger.error(`RdbHelper taskInfo err : ${JSON.stringify(err)}`);
        });
        RdbUtils.createTable('formInfo', columnFormInfoList)
            .catch((err) => {
            Logger.error(`RdbHelper formInfo err : ${JSON.stringify(err)}`);
        });
        RdbUtils.createTable('personInfo', columnPersonInfoList).then(() => {
            Logger.info(`RdbHelper createTable personInfo success`);
        }).catch((err) => {
            Logger.error(`RdbHelper personInfo err : ${JSON.stringify(err)}`);
        });
        RdbUtils.createTable('prayInfo', columnPrayInfoList).then(() => {
            Logger.info(`RdbHelper createTable prayInfo success`);
        }).catch((err) => {
            Logger.error(`RdbHelper prayInfo err : ${JSON.stringify(err)}`);
        });
        PersonInfoApi.query_all((res) => {
            res.forEach(item => {
                PersonList.addPerson(item);
            });
            console.log('hhcpersonlist: ' + res.length);
            if (res.length == 0) {
                PersonList.addPerson(new PersonInfo('韩昊辰', '父亲', 0));
                PersonList.addPerson(new PersonInfo('张三', '儿子', 0));
                PersonList.addPerson(new PersonInfo('小红', '女儿', 0));
                PersonInfoApi.insertData(new PersonInfo('韩昊辰', '父亲', '0'), () => { });
                PersonInfoApi.insertData(new PersonInfo('张三', '儿子', '0'), () => { });
                PersonInfoApi.insertData(new PersonInfo('小红', '女儿', '0'), () => { });
                console.log('初始化personlist成功');
            }
        });
    }
    onDestroy() {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage) {
        // Main window is created, set main page for this ability
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageCreate');
        windowStage.loadContent('pages/Index', (err, data) => {
            var _a, _b;
            if (err.code) {
                hilog.error(0x0000, 'testTag', 'Failed to load the content. Cause: %{public}s', (_a = JSON.stringify(err)) !== null && _a !== void 0 ? _a : '');
                return;
            }
            hilog.info(0x0000, 'testTag', 'Succeeded in loading the content. Data: %{public}s', (_b = JSON.stringify(data)) !== null && _b !== void 0 ? _b : '');
        });
    }
    onWindowStageDestroy() {
        // Main window is destroyed, release UI related resources
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground() {
        // Ability has brought to foreground
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
    }
    onBackground() {
        // Ability has back to background
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
    }
}
EntryAbility.TAG = 'EntryAbility';
//# sourceMappingURL=EntryAbility.js.map