import TaskInfo from '@bundle:com.example.houseworkapp/entry/ets/viewmodel/TaskInfo';
class TaskEdit extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = new ObservedPropertyObjectPU(new TaskInfo(0, '', 0, '', false, '', '', '', false, '', false, '', '', '', ''), this, "editTask");
        this.addProvidedVar("editTask", this.__editTask);
        this.isChanged = false;
        this.setInitiallyProvidedValue(params);
        this.declareWatch("editTask", this.onTaskChanged);
    }
    setInitiallyProvidedValue(params) {
        if (params.editTask !== undefined) {
            this.editTask = params.editTask;
        }
        if (params.isChanged !== undefined) {
            this.isChanged = params.isChanged;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    onTaskChanged() {
        this.isChanged = true;
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("hihihi");
            Text.debugLine("pages/TaskEdit.ets(24:5)");
            Text.width(423);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export class EditNameItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__editTask = this.initializeConsume("editTask", "editTask");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__editTask.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get editTask() {
        return this.__editTask.get();
    }
    set editTask(newValue) {
        this.__editTask.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/TaskEdit.ets(53:5)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('编辑任务标题');
            Text.debugLine("pages/TaskEdit.ets(54:7)");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Medium);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create();
            TextInput.debugLine("pages/TaskEdit.ets(58:7)");
            TextInput.maxLength(5);
            TextInput.width(300);
            TextInput.height(50);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    previewComponent();
}
else {
    storePreviewComponents(2, "TaskEdit", new TaskEdit(undefined, {}), "EditNameItem", new EditNameItem(undefined, {}));
    ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
    loadDocument(new TaskEdit(undefined, {}));
    ViewStackProcessor.StopGetAccessRecording();
}
//# sourceMappingURL=TaskEdit.js.map