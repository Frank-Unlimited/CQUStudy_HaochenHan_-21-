export class PersonList {
    constructor() { }
    static addPerson(newPerson) {
        if (this.personMap.has(newPerson.personName))
            return 1;
        this.personMap.set(newPerson.personName, newPerson);
        console.log('PersonList Insert Person:' + JSON.stringify(newPerson));
        console.log('PersonList: ' + JSON.stringify(this.personMap['韩昊辰']));
        return 0;
    }
    static updatePerson(person) {
        this.personMap.set(person.personName, person);
    }
    static queryByName(name) {
        return this.personMap.get(name);
    }
}
PersonList.personMap = new Map();
//# sourceMappingURL=PersonList.js.map